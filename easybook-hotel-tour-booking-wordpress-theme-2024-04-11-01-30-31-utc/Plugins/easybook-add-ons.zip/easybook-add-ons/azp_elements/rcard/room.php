<?php
/* add_ons_php */
azp_add_element(
    'rcard_room',
    array(
        'name'                    => __('Room Card', 'easybook-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','easybook-add-ons'),
        'category'                => 'Room Card',
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'is_section'              => true,
        // 'has_children'            => true,
        'template_folder'         => 'rcard/',
        'attrs'                   => array(
            array(
                'type'                  => 'icon',
                'param_name'            => 'azp_icon',
                'show_in_admin'         => true,
                'label'                 => __('Icon Selector','easybook-add-ons'),
                'desc'                  => '',
                'default'               => 'far fa-long-arrow-right'
            ),
            array(
                'type'                  => 'text',
                'param_name'            => 'num_feature',
                'label'                 => __('Number of Features to show','easybook-add-ons'),
                'desc'                  => '',
                'default'               => '5'
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'easybook-add-ons'),
                // 'desc'                  => '',
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'easybook-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-add-ons'),
                'default'    => '',
            ),
        ),
    )
);
