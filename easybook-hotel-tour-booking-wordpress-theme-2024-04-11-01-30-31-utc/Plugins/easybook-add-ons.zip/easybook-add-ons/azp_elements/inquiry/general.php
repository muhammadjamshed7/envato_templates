<?php
/* add_ons_php */
azp_add_element(
    'booking_inquiry',
    array(
        'name'                    => __('General Inquiry', 'easybook-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','easybook-add-ons'),
        'category'                => __("Booking Inquiry", 'easybook-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'template_folder'         => 'inquiry/',
        'attrs'                   => array(
            array(
                'type'          => 'text',
                'param_name'    => 'title',
                'show_in_admin' => true,
                'label'         => __('Title', 'easybook-add-ons'),
                'default'       => 'Booking Inquiry',
            ),
            
            array(
                'type'        => 'checkbox',
                'param_name'  => 'hide_widget_on',
                // 'show_in_admin'         => true,
                'label'       => __('Hide this widget on', 'easybook-add-ons'),
                'desc'        => __('Hide on logout user or based author plan?', 'easybook-add-ons'),
                'default'     => '',
                'value'       => easybook_addons_loggedin_plans_options(),
                'multiple'    => true,
                'show_toggle' => true,
            ),



            // array(
            //     'type'       => 'select',
            //     'param_name' => 'bprice',
            //     // 'show_in_admin'         => true,
            //     'label'      => __('Price Based', 'easybook-add-ons'),
            //     'desc'       => '',
            //     'default'    => 'per_night',
            //     'value'      => array(
            //         'per_person'   => __('Per person', 'easybook-add-ons'),
            //         'per_night'    => __('Per night', 'easybook-add-ons'),
            //         'night_person' => __('Per person/night', 'easybook-add-ons'),
            //         'per_day'      => __('Per day', 'easybook-add-ons'),
            //         'day_person'   => __('Per person/day', 'easybook-add-ons'),
            //         'listing'   => __('Per listing', 'easybook-add-ons'),
            //         'none'         => __('No listing price', 'easybook-add-ons'),

            //     ),
            // ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_name',
                'show_in_admin' => true,
                'label'         => __('Show name on logged in user?', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_email',
                'show_in_admin' => true,
                'label'         => __('Show email on logged in user?', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_phone',
                'show_in_admin' => true,
                'label'         => __('Show phone on logged in user?', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'checkin_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Checkin?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'checkout_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Checkout?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'dlabel',
                'label'      => __('Date picker label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Date',
            ),

            array(
                'type'       => 'icon',
                'param_name' => 'dicon',
                'label'      => __('Date picker icon', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'fal fa-calendar-check',
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'dformat',
                'show_in_admin' => true,
                'label'         => __('Date Format', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'DD/MM/YYYY',
                'value'         => array(
                    'DD-MM-YYYY' => __('28-02-2019', 'easybook-add-ons'),
                    'DD/MM/YYYY' => __('28/02/2019', 'easybook-add-ons'),

                    'MM-DD-YYYY' => __('02-28-2019', 'easybook-add-ons'),
                    'MM/DD/YYYY' => __('02/28/2019', 'easybook-add-ons'),

                    'YYYY-MM-DD' => __('2019-02-28', 'easybook-add-ons'),
                    'YYYY/MM/DD' => __('2019/02/28', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'slots_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Time Slots?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '0',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'sllable',
                'label'      => __('Time slots label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Time Slots',
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'tpicker_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Time Picker?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'tlabel',
                'label'      => __('Time picker label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Time',
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'tformat',
                'show_in_admin' => true,
                'label'         => __('Time Format', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'H:i:s',
                'value'         => array(
                    'g:i a' => __('8:30 am', 'easybook-add-ons'),
                    'g:i A' => __('8:30 AM', 'easybook-add-ons'),
                    'h:i a' => __('08:30 am', 'easybook-add-ons'),
                    'h:i A' => __('08:30 AM', 'easybook-add-ons'),
                    'G:i:s' => __('8:30:00 (24-hour)', 'easybook-add-ons'),
                    'H:i:s' => __('08:30:00 (24-hour)', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'icon',
                'param_name' => 'ticon',
                'label'      => __('Time picker icon', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'fal fa-clock',
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'adult_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Adults?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'adult_lbl',
                'label'      => __('Adults field label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Adults',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'adult_desc',
                'label'      => __('Adults field description', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Age 18+',
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'child_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Children?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'child_lbl',
                'label'      => __('Children field label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Children',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'child_desc',
                'label'      => __('Children field description', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Age 6-17',
            ),

            array(
                'type'       => 'switch',
                'param_name' => 'infant_show',
                // 'show_in_admin'         => true,
                'label'      => __('Show Infant?', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '1',
                'value'      => array(
                    '1' => __('Yes', 'easybook-add-ons'),
                    '0' => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'infant_lbl',
                'label'      => __('Infant field label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Infant',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'infant_desc',
                'label'      => __('Infant field description', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Age 0-5',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_notes',
                'show_in_admin' => true,
                'label'         => __('Show Additional Infos', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_quantity',
                'label'         => __('Show Quantity', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'qtt_lbl',
                'label'      => __('Quantity field label', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => 'Quantity',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'qtt_desc',
                'label'      => __('Quantity field description', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_lservices',
                'label'         => __('Show Extra Services?', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'quanity_lservices',
                'label'         => __('Allow quantity for Extra Services?', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'easybook-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
