<?php
/* add_ons_php */
azp_add_element(
    'preview_listing',
    array(
        'name'                    => __('Listing Card', 'easybook-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','easybook-add-ons'),
        'category'                => __("Preview Template", 'easybook-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'is_section'              => true,
        'has_children'            => true,
        'attrs'                   => array(
            
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_overlay',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide dark overlay', 'easybook-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => __('Yes', 'easybook-add-ons'),
            //         'no'  => __('No', 'easybook-add-ons'),
            //     ),
            // ),
            // array(
            //     'type'          => 'switch',
            //     'param_name'    => 'hide_status',
            //     'show_in_admin' => true,
            //     'label'         => __('Hide Open/Closed status', 'easybook-add-ons'),
            //     'desc'          => '',
            //     'default'       => 'no',
            //     'value'         => array(
            //         'yes' => __('Yes', 'easybook-add-ons'),
            //         'no'  => __('No', 'easybook-add-ons'),
            //     ),
            // ),
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_author',
                'show_in_admin' => true,
                'label'         => __('Hide author', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_rating',
                'show_in_admin' => true,
                'label'         => __('Hide rating', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),
            array(
                'type'          => 'switch',
                'param_name'    => 'hide_saleoff',
                'show_in_admin' => true,
                'label'         => __('Hide Sale Off', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'easybook-add-ons'),
                    'no'  => __('No', 'easybook-add-ons'),
                ),
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'easybook-add-ons'),
                // 'desc'                  => '',
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'easybook-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-add-ons'),
                'default'    => '',
            ),
        ),
    )
);
