<?php
/* add_ons_php */
azp_add_element(
    'lrooms_new',
    array(
        'name'                    => __('Rooms Booking (NEW)', 'easybook-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','easybook-add-ons'),
        'category'                => __("Instant Booking", 'easybook-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'template_folder'         => 'instant/',
        'attrs'                   => array(
            array(
                'type'          => 'text',
                'param_name'    => 'title',
                'show_in_admin' => true,
                'label'         => __('Title', 'easybook-add-ons'),
                'default'       => 'Rooms Booking',
            ),
            
            array(
                'type'        => 'checkbox',
                'param_name'  => 'hide_widget_on',
                // 'show_in_admin'         => true,
                'label'       => __('Hide this widget on', 'easybook-add-ons'),
                'desc'        => __('Hide on logout user or based author plan?', 'easybook-add-ons'),
                'default'     => '',
                'value'       => easybook_addons_loggedin_plans_options(),
                'multiple'    => true,
                'show_toggle' => true,
            ),

            

            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'easybook-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
