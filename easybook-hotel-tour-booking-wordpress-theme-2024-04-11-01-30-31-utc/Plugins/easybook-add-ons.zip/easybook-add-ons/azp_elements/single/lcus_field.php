<?php
/* add_ons_php */
azp_add_element(
    'lcus_field',
    array(
        'name'                    => __('Custom Field', 'easybook-add-ons'),
        // 'desc'                  => __('Custom element for adding third party shortcode','easybook-add-ons'),
        'category'                => __("Custom", 'easybook-add-ons'),
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => true,
        'showTypographyTab'       => true,
        'showAnimationTab'        => true,
        'template_folder'         => 'single/',
        'attrs'                   => array(
            array(
                'type'          => 'text',
                'param_name'    => 'title',
                'show_in_admin' => true,
                'label'         => __('Title', 'easybook-add-ons'),
                'default'       => 'Title',
            ),
            array(
                'type'          => 'selectcfield',
                'param_name'    => 'name',
                'show_in_admin' => true,
                'label'         => __('Field name', 'easybook-add-ons'),
                'desc'          => '',
                'default'       => '',
                'value'         => array(),
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'width',
                'show_in_admin' => true,
                'label'         => __('Width', 'easybook-add-ons'),
                // 'desc'                  => 'Select how to sort retrieved posts.',
                'default'       => '12',
                'value'         => array(
                    '12' => __('1/1', 'easybook-add-ons'),
                    '10' => __('5/6', 'easybook-add-ons'),
                    '9'  => __('3/4', 'easybook-add-ons'),
                    '8'  => __('2/3', 'easybook-add-ons'),
                    '7'  => __('7/12', 'easybook-add-ons'),
                    '6'  => __('1/2', 'easybook-add-ons'),
                    '5'  => __('5/12', 'easybook-add-ons'),
                    '4'  => __('1/3', 'easybook-add-ons'),
                    '3'  => __('1/4', 'easybook-add-ons'),
                    '2'  => __('1/6', 'easybook-add-ons'),
                    '1'  => __('1/12', 'easybook-add-ons'),

                ),
            ),
            array(
                'type'       => 'text',
                'param_name' => 'el_id',
                'label'      => __('Element ID', 'easybook-add-ons'),
                'desc'       => '',
                'default'    => '',
            ),

            array(
                'type'       => 'text',
                'param_name' => 'el_class',
                'label'      => __('Extra Class', 'easybook-add-ons'),
                'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'easybook-add-ons'),
                'default'    => '',
            ),

        ),
    )
);
