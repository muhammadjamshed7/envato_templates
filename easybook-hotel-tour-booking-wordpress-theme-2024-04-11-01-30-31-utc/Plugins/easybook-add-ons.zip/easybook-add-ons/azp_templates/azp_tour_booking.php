<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $hide_widget_on = $wid_title = $dformat = $dlabel = $dicon = ''; 
$adult_show = $adult_lbl = $adult_desc = $child_show = $child_lbl = $child_desc = $infant_show = $infant_lbl = $infant_desc = '';
$show_lservices = $quanity_lservices = $show_quantity = $qtt_lbl = $qtt_desc = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'azp_tour_booking',
    'azp-element-' . $azp_mID,
    $el_class,
);
$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}

// array(5) { ["checkout"]=> string(10) "2018-12-20" ["checkin"]=> string(10) "2018-12-19" ["lb_adults"]=> string(1) "1" ["lb_children"]=> string(1) "0" ["rooms"]=> array(1) { [5174]=> string(1) "2" } }
if(( $hide_widget_on_check = easybook_addons_is_hide_on_plans($hide_widget_on) ) !== 'true') :
$curr_attrs = easybook_addons_get_currency_attrs();
$listing_type_id = get_post_meta( get_the_ID(), ESB_META_PREFIX.'listing_type_id', true );
$bprice = get_post_meta( $listing_type_id, ESB_META_PREFIX.'price_based', true );
if($bprice === '') $bprice = 'listing';

$symbol_multiple = sprintf( __( '%s<span class="multiplication">x</span>', 'easybook-add-ons' ), easybook_addons_get_currency_symbol() );
$max_guests = easybook_addons_listing_max_guests();
?>
<div class="<?php echo $classes; ?> authplan-hide-<?php echo $hide_widget_on_check;?>" <?php echo $el_id;?>>
    <div class="for-hide-on-author"></div>
	<div class="box-widget-item fl-wrap" id="widget-tour-booking">
	    <?php if($wid_title != ''): ?>
	    <div class="box-widget-item-header">
	        <h3><?php echo $wid_title; ?></h3>
	    </div>
		<?php endif; ?>
	    <div class="tour-booking-inner">
	        <form method="POST" name="esb-tour-booking"> 
	        	<div class="cth-date-picker-wrap esb-field has-icon">
	        		<div class="lfield-header">
		        		<label class="lfield-label"><?php echo esc_html( $dlabel ); ?></label>
                        <span class="lfield-icon"><i class="<?php echo esc_attr( $dicon ); ?>"></i></span>
		        	</div>
					<div class="cth-date-picker" 
						data-name="checkin" 
						data-format="<?php echo $dformat; ?>" 
						data-default=""
						data-action="listing_dates" 
						data-postid="<?php the_ID();?>" 
						data-selected="tour_date"
					></div>
	        	</div>
		        
		  

	        	<?php if($adult_show === '1'): ?>
                <div class="qtt-item qtt-item-full qtt-item-js fl-wrap m-b20">
                    <div class="qtt-label-wrap">
                        <?php if($adult_lbl != ''): ?><label class="qtt-label"><?php echo $adult_lbl; ?></label><?php endif; ?>
                        <?php if($adult_desc != ''): ?><span><?php echo $adult_desc; ?></span><?php endif; ?>
                    </div>
                    <div class="qtt-price text-right">
                        <input class="hids-input jscal-price" readonly="readonly" type="text" name="price_adult" value="<?php echo easybook_addons_get_price( get_post_meta( get_the_ID(), '_price', true ) ); ?>"><?php echo $symbol_multiple; ?>
                    </div>
                    <div class="qtt-input">
                        <input type="number" name="adults" min="0" max="<?php echo $max_guests; ?>" step="1" value="1">
                        <div class="qtt-nav">
                            <div class="qtt-btn qtt-up">+</div>
                            <div class="qtt-btn qtt-down">-</div>
                        </div>
                    </div>

                    
                    <input class="hid-input" type="text" name="item_total" value="" jAutoCalc="{adults} * {price_adult}">

                </div>
                <?php endif; ?>
                <?php if($child_show === '1'): ?>
                <div class="qtt-item qtt-item-full qtt-item-js fl-wrap m-b20">
                    <div class="qtt-label-wrap">
                        <?php if($child_lbl != ''): ?><label class="qtt-label"><?php echo $child_lbl; ?></label><?php endif; ?>
                        <?php if($child_desc != ''): ?><span><?php echo $child_desc; ?></span><?php endif; ?>
                    </div>
                    <div class="qtt-price text-right">
                        <input class="hids-input jscal-price" readonly="readonly" type="text" name="price_children" value="<?php echo easybook_addons_get_price( get_post_meta( get_the_ID(), ESB_META_PREFIX .'children_price', true ) ); ?>"><?php echo $symbol_multiple; ?>
                    </div>
                    <div class="qtt-input">
                        <input type="number" name="children" min="0" max="<?php echo $max_guests; ?>" step="1" value="0">
                        <div class="qtt-nav">
                            <div class="qtt-btn qtt-up">+</div>
                            <div class="qtt-btn qtt-down">-</div>
                        </div>
                    </div>

                    
                    <input class="hid-input" type="text" name="item_total" value="" jAutoCalc="{children} * {price_children}">

                </div>
                <?php endif; ?>
                <?php if($infant_show === '1'): ?>
                <div class="qtt-item qtt-item-full qtt-item-js fl-wrap m-b20">
                    <div class="qtt-label-wrap">
                        <?php if($infant_lbl != ''): ?><label class="qtt-label"><?php echo $infant_lbl; ?></label><?php endif; ?>
                        <?php if($infant_desc != ''): ?><span><?php echo $infant_desc; ?></span><?php endif; ?>
                    </div>
                    <div class="qtt-price text-right">
                        <input class="hids-input jscal-price" readonly="readonly" type="text" name="price_infant" value="<?php echo easybook_addons_get_price( get_post_meta( get_the_ID(), ESB_META_PREFIX .'infant_price', true ) ); ?>"><?php echo $symbol_multiple; ?>
                    </div>
                    <div class="qtt-input">
                        <input type="number" name="infants" min="0" max="<?php echo $max_guests; ?>" step="1" value="0">
                        <div class="qtt-nav">
                            <div class="qtt-btn qtt-up">+</div>
                            <div class="qtt-btn qtt-down">-</div>
                        </div>
                    </div>

                    
                    <input class="hid-input" type="text" name="item_total" value="" jAutoCalc="{infants} * {price_infant}">

                </div>
                <?php endif; ?>

		        <?php 
                if( $show_lservices == 'yes' ):
                $lservices = get_post_meta( get_the_ID(), ESB_META_PREFIX.'lservices', true );
                if( !empty($lservices) && is_array($lservices) ){ ?>
                    <?php if($quanity_lservices == 'yes'): ?>
                    <div class="lservices-qtts-wrap">
                        <label class="lservices-qtts-label"><?php esc_html_e( 'Extra Services', 'easybook-add-ons' ); ?></label>
                        <?php
                        // $serprefix = uniqid('lserv');
                        foreach ($lservices as $serv) {
                            $serprice_name = $serv['service_id'] ."_price";
                            $serqtt_name = 'bk_services['.$serv['service_id'].']';
                            $serqtt_id = uniqid('lserv');
                        ?>
                            <div class="lservices-qtts-item">
                                <div class="qtt-item qtt-item-full qtt-item-js">
                                    <div class="qtt-label-wrap"><?php echo esc_html($serv['service_name']);?></div>
                                    
                                    <div class="qtt-price text-right">
                                        <input class="hids-input jscal-price" readonly="readonly" type="text" name="<?php echo esc_attr( $serprice_name ); ?>" value="<?php echo easybook_addons_get_price( $serv['service_price'] ); ?>"><?php echo $symbol_multiple; ?>
                                    </div>
                                    
                                    <div class="qtt-input">
                                        <input type="number" id="<?php echo esc_attr( $serqtt_id ); ?>" name="<?php echo esc_attr( $serqtt_name ); ?>" min="0" step="1" value="0">
                                        <div class="qtt-nav">
                                            <div class="qtt-btn qtt-up">+</div>
                                            <div class="qtt-btn qtt-down">-</div>
                                        </div>
                                    </div>
                                    
                                    <input class="hid-input" type="text" name="item_total" value="" data-jcalc="{#<?php echo esc_attr( $serqtt_id ); ?>} * {<?php echo esc_attr( $serprice_name ); ?>}">
                                    
                                </div>
                            </div>
                            <?php
                        } ?>
                    </div>
                    <?php else : ?>
                    <div class="lservices-row">
                        <div class="cth-dropdown-warp">
                            <div class="cth-dropdown-header"><label><?php esc_html_e('Extra Services','easybook-add-ons') ?><span class="count-select-ser">0</span></label></div>
                            <div class="cth-dropdown-options">
                                <div class="cth-dropdown-inner">
                                    <?php
                                    $serprefix = uniqid('lserv');
                                    foreach ($lservices as $serv) {
                                        $serv_price = easybook_addons_get_price( $serv['service_price'] );
                                    ?>
                                        <div class="cth-dropdown-item lserv-dropdown">
                                            <input type="checkbox" id="<?php echo $serprefix .'-'. esc_attr($serv['service_id']);?>" name='addservices[]' class="lserv-item-checkbox" data-price="<?php echo $serv_price;?>" value="<?php echo esc_attr($serv['service_id']);?>">
                                            <label for="<?php echo $serprefix .'-'. esc_attr($serv['service_id']);?>"><?php echo esc_html($serv['service_name']);?><span class="cth-dropdown-meta"><?php echo easybook_addons_get_price_formated( $serv['service_price'] );?></span></label>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                        <input class="hid-input" type="text" name="item_total" value="0">
                    </div>
                <?php 
                    endif;
                    } 
                endif;
                ?>     

				<div class="total-coast fl-wrap clearfix">
					<strong><?php _e( 'Total Cost', 'easybook-add-ons' ); ?></strong>
					<span><input class="total-cost-input" type="text" name="grand_total" value="" jAutoCalc="SUM({item_total})"><?php echo easybook_addons_get_currency_symbol(); ?></span>
				</div>

				<div class="booking-buttons">
					<button class="btn btnaplly color2-bg"  type="submit"><?php esc_html_e( 'Book Now', 'easybook-add-ons' ); ?><i class="fal fa-paper-plane"></i></button>
				</div>

	        	<input type="hidden" name="booking_type" value="tour">
                <input type="hidden" name="price_based" value="<?php echo esc_attr( $bprice ); ?>">
	        	<input type="hidden" name="product_id" value="<?php the_ID(); ?>">
	        	<input type="hidden" name="action" value="esb_add_to_cart">
	        	<input type="hidden" name="_wpnonce" value="<?php echo wp_create_nonce('easybook-add-to-cart'); ?>">
                
            </form>

	    </div>
	</div>
</div>
<?php
endif; 