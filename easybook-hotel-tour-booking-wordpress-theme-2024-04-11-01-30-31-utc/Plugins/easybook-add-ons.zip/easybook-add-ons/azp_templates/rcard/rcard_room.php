<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $num_feature = $azp_icon = ''; 

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'rcard_room',
    'azp-element-' . $azp_mID,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id != ''){
    $el_id = 'id="'.$el_id.'"';
}
$price = get_post_meta( get_the_ID(), '_price', true );
$adults = get_post_meta( get_the_ID(), ESB_META_PREFIX.'adults', true );
$children = get_post_meta( get_the_ID(), ESB_META_PREFIX.'children', true );
$max_guests = intval($adults) + intval($children);

$gallery_imgs_room = get_post_meta( get_the_ID(), ESB_META_PREFIX.'room_images', true );
if ( !empty($gallery_imgs_room) ) {
    if( !is_array($gallery_imgs_room) ){
        $gallery_imgs_room = explode(",", $gallery_imgs_room);
    }
}   
$gMoreImages = array();
$gMoreImage = get_post_thumbnail_id( get_the_ID() );
foreach ((array)$gallery_imgs_room as $key =>  $id ) {
    if( empty($gMoreImage) ) $gMoreImage = $id;
    $gMoreImages[] = array('src'=> wp_get_attachment_url($id), 'subHtml'=> get_the_title($id) );
}
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="lrooms-item fl-wrap">
        <?php if( !empty($gMoreImage) ): ?>
        <div class="lrooms-media rooms-media">
            <?php echo wp_get_attachment_image( $gMoreImage, 'full', false, array('class'=>'respimg') ); ?>
            <div class="dynamic-gal more-photos-button" data-dynamicPath='<?php echo json_encode($gMoreImages);?>'><?php esc_html_e( 'View Gallery', 'easybook-add-ons' );?><?php echo sprintf(__( '<span>%s photos</span>', 'easybook-add-ons' ), count($gallery_imgs_room) ) ?><?php if(!empty($azp_icon)): ?><i class="<?php echo esc_attr( $azp_icon ); ?>"></i><?php endif; ?></div>
        </div>
        <?php endif; ?>
        <div class="rooms-details">
            <div class="rooms-details-header fl-wrap">
                <?php if( !empty($price) ): ?><span class="lrooms-price rooms-price"><?php echo sprintf(__( '%s <strong>/ night</strong>', 'easybook-add-ons' ), easybook_addons_get_price_formated($price) ) ?></span><?php endif; ?>
                <h3><?php the_title(); ?></h3>
                <?php if( !empty($max_guests) ): ?><h5><?php echo sprintf(__( 'Max Guests: <span>%d persons</span>', 'easybook-add-ons' ), $max_guests); ?></h5><?php endif; ?>
            </div>
            <div class="lrooms-desc">
                <?php 
                // the_excerpt();
                easybook_addons_the_excerpt_max_charlength(easybook_addons_get_option('excerpt_length','55'));
                ?>
            </div>
            <div class="roomCard-bot">
                <?php 
                $features = get_the_terms(get_the_ID(), 'listing_feature');
                if ( $features && ! is_wp_error( $features ) ){ 
                    $feature_group = array();
                    foreach( $features as $key => $term){
                        if(easybook_addons_get_option('feature_parent_group') == 'yes'){ 
                            if($term->parent){
                                if( !isset($feature_group[$term->parent]) || !is_array($feature_group[$term->parent]) ) $feature_group[$term->parent] = array();
                                $feature_group[$term->parent][$term->term_id] = $term->name;
                            }else{
                                if(!isset($feature_group[$term->term_id])) $feature_group[$term->term_id] = $term->name;
                            }
                        }else{
                            if(!isset($feature_group[$term->term_id])) $feature_group[$term->term_id] = $term->name;
                        }
                            
                    }
                ?>
                <div class="room-preview-fact fl-wrap">
                    <ul class="facilities-list fl-wrap">
                        <?php
                        $count = 1;
                        foreach( $feature_group as $tid => $tvalue){
                            // var_dump($tvalue);
                            if($count <= (int)$num_feature){
                                if( is_array( $tvalue ) && count( $tvalue ) ){
                                    $term = get_term_by( 'id', $tid , 'listing_feature' );
                                    if($term){
                                        $term_meta = get_term_meta( $term->term_id, ESB_META_PREFIX.'term_meta', true );

                                        echo sprintf( '<li class="fea-has-children">%1$s<ul class="fea-children">',
                                            isset($term_meta['icon_class'])? '<i class="'.$term_meta['icon_class'].'"></i>' . esc_html( $term->name ) : esc_html( $term->name )
                                        );

                                        foreach ($tvalue as $id => $name) {
                                            $term_meta = get_term_meta( $id, ESB_META_PREFIX.'term_meta', true );

                                            echo sprintf( '<li>%1$s</li>',
                                                isset($term_meta['icon_class'])? '<i class="'.$term_meta['icon_class'].'"></i>' . esc_html( $name ) : esc_html( $name )
                                            );
                                        }

                                        echo '</ul></li>';
                                    }
                                    
                                }else{
                                    $term_meta = get_term_meta( $tid, ESB_META_PREFIX.'term_meta', true );
                                    echo sprintf( '<li>%1$s</li>',
                                        isset($term_meta['icon_class'])? '<i class="'.$term_meta['icon_class'].'"></i>'.'<span class="fea-tooltip">' . esc_html( $tvalue ).'</span>' : esc_html( $tvalue )
                                    );
                                }
                            }  
                            $count++;                 
                        }
                    ?>
                    </ul>
                    
                </div>
                <?php } ?>
                <div class="lroom-dbtn"><button class="btn big-btn color-bg ajax-link" data-roomid="<?php echo esc_attr( get_the_ID() );?>"><?php esc_html_e( 'Details' ,'easybook-add-ons'); ?><i class="fas fa-caret-right"></i></button></div>
            </div>
        </div>
    </div>
</div>