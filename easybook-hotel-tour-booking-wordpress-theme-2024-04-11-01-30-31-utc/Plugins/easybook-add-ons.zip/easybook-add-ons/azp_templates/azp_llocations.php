<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $sec_id = $title = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
    'azp_element',
    'azp_llocations',
    'azp-element-' . $azp_mID,
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) ); 

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
$terms = wp_get_post_terms( get_the_ID(), 'listing_location', array( "fields" => "ids" ) );
if ( $terms && ! is_wp_error( $terms ) ){ 

?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="list-single-main-items fl-wrap">
        <?php if($title != ''): ?>
        <div class="list-single-main-item-title no-dec-title fl-wrap">
            <h3><?php echo $title; ?></h3>
        </div>
        <?php endif; ?>
        <div class="list-single-locations">
            
            <?php 
            $terms = trim( implode( ',', (array) $terms ), ' ,' );
            wp_list_categories( 'style=flat&separator=&title_li=&taxonomy=' . 'listing_location' . '&include=' . $terms );

            ?> 
            
                                                                                             
        </div>
    </div>
</div>
<?php }

