<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $hide_status = $hide_bookmark = $hide_overlay = $hide_author = $hide_rating = $hide_saleoff = '';

// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
    'azp_element',
    'preview_listing',
    'azp-element-' . $azp_mID,
    'geodir-category-img',
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace('/\s+/', ' ', implode(' ', array_filter($classes)));

if ($el_id != '') {
    $el_id = 'id="' . $el_id . '"';
}
if( $hide_overlay == 'yes' ) $classes .= ' card-hide-overlay';
// if (has_post_thumbnail()) {
?>
<div class="<?php echo $classes; ?>" <?php echo $el_id; ?>>
    <div class="geodir-category-img">
        <a href="<?php the_permalink();?>" class="listing-thumb-link geodir-category-img-wrap fl-wrap">
            <?php 
            echo wp_get_attachment_image( easybook_addons_get_listing_thumbnail( get_the_ID() ) , 'easybook-listing-grid', false, array('class'=>'respimg') );
            ?>

            
        </a>
        <?php if( $hide_author != 'yes' ): ?>
        <div class="listing-avatar">
            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename')); ?>"><?php
            echo get_avatar(get_the_author_meta('user_email'), '80', 'https://0.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536?s=80', get_the_author_meta('display_name'));
            ?></a>
            <span class="avatar-tooltip"><?php echo sprintf(__('Added By <strong>%s</strong>', 'easybook-add-ons'), get_the_author()); ?></span>
        </div>
        <?php endif; ?>

        <?php 
        $saleoff = get_post_meta( get_the_ID(), ESB_META_PREFIX.'sale_price', true );
        if( $hide_saleoff != 'yes' ):
        
        if( !empty($saleoff) ): ?>
            <div class="preview_sale">
                <div class="sale-window<?php if($saleoff >= 50) echo ' big-sale';?>"><?php echo sprintf(__( "Sale %s%%", 'easybook-add-ons' ), $saleoff); ?></div>
            </div>

        <?php endif;
        endif; ?> 
        <?php if( get_post_meta( get_the_ID(), ESB_META_PREFIX.'featured', true ) == '1' ): ?>
            <div class="listing-featured<?php if($saleoff != '') echo ' listing-featured-fix';?>"><?php _e( 'Featured', 'easybook-add-ons' ); ?></div>
        <?php endif; ?>
        <?php 
        if( $hide_rating != 'yes' ):
        $rating = easybook_addons_get_average_ratings(get_the_ID());    ?>
        <?php if( $rating != false ): ?>
            <div class="geodir-category-opt clearfix">
                
                <div class="listing-rating-count-wrap flex-items-center">
                    <div class="listing-rating card-popup-rainingvis" data-starrating2="<?php echo $rating['sum']; ?>"></div>
                    
                    <div class="rate-class-name">
                        <div class="score">
                            <strong class="review-text"><?php echo easybook_addons_rating_text($rating['sum']); ?></strong>
                            <?php echo sprintf( _nx( '%s comment', '%s comments', (int)$rating['count'], 'comments count', 'easybook-add-ons' ), (int)$rating['count'] ); ?>
                        </div>
                        <span class="review-score"><?php echo $rating['sum']; ?></span>
                    </div>
                </div>
            </div>
        <?php endif;
        endif; ?> 
        <?php do_action( 'cth_listing_card_thumbnail' ); ?>
        <div class="lcfields-wrap dis-flex"><?php echo wp_kses_post( $azp_content ); ?></div>
    </div>

    
</div>
<?php // }
