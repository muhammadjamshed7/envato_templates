<?php
/* add_ons_php */

//$azp_attrs,$azp_content,$azp_element
$azp_mID = $el_id = $el_class = $images_to_show = $hide_address = $hide_excerpt = $hide_features = $hide_cats = $hide_price_range = 
$hide_contacts = $hide_view_map = $hide_gallery = $hide_footer = $show_price = '';
$hide_bookmark = '';
// var_dump($azp_attrs);
extract($azp_attrs);

$classes = array(
	'azp_element',
    'preview_listing_content',
    'azp-element-' . $azp_mID,
    'geodir-category-content',
    $el_class,
);
// $animation_data = self::buildAnimation($azp_attrs);
// $classes[] = $animation_data['trigger'];
// $classes[] = self::buildTypography($azp_attrs);//will return custom class for the element without dot
// $azplgallerystyle = self::buildStyle($azp_attrs);

$classes = preg_replace( '/\s+/', ' ', implode( ' ', array_filter( $classes ) ) );

if($el_id!=''){
    $el_id = 'id="'.$el_id.'"';
}
// if(has_post_thumbnail( )){ ?>
<div class="<?php echo $classes; ?>" <?php echo $el_id;?>>
    <div class="geodir-category-content-title fl-wrap">
        <div class="geodir-category-content-title-item">
            <h3 class="title-sin_map">
                <?php if( $GLOBALS['is_lad'] ) echo '<span class="litem-ad">'.__( 'AD', 'easybook-add-ons' ).'</span>'; ?>
                <a href="<?php the_permalink(  ); ?>"><?php 
                    the_title(); 
                    // $title = get_the_title( get_the_ID() );
                    // echo substr($title, 0, 100);
                ?></a>
                <?php if( get_post_meta( get_the_ID(), ESB_META_PREFIX.'verified', true ) == '1' ): ?>
                    <span class="verified-badge"><i class="fal fa-check"></i></span>
                <?php endif; ?>
            </h3>
            <?php if( $hide_address != 'yes'): ?><div class="geodir-category-location fl-wrap"><a href="#" class="single-map-item"><i class="fas fa-map-marker-alt"></i><?php 
                $address = get_post_meta( get_the_ID(), ESB_META_PREFIX.'address', true ); 
                echo esc_html( $address );
                // echo substr($address, 0, 100);
            ?></a></div><?php endif; ?>
            
            
        </div>
    </div>
    <?php 
    // the_excerpt();
    if( $hide_excerpt != 'yes'){
        echo '<div class="lcard-desc">';
            easybook_addons_the_excerpt_max_charlength( easybook_addons_get_option('excerpt_length','55') );
        echo '</div>';
    } 
    ?>
    <div class="lcfields-wrap dis-flex"><?php echo wp_kses_post( $azp_content ); ?></div>
    <?php 
    if( $hide_features != 'yes'):
    $terms = get_the_terms(get_the_ID(), 'listing_feature');
    if ( $terms && ! is_wp_error( $terms ) ){  
    ?>
    <ul class="facilities-list fl-wrap">
            <?php 
            $count = 1;
            foreach ($terms as $term) {
                if($count > 4) break;
                $term_metas = easybook_addons_custom_tax_metas($term->term_id, 'listing_feature'); 
                //get_term_meta( $term->term_id, ESB_META_PREFIX.'term_meta', true );
                ?>
                <li class="tolt"  data-microtip-position="top" data-tooltip="<?php echo esc_attr( $term->name ); ?>">
                    <i class="<?php echo esc_attr( $term_metas['icon'] ); ?>"></i>
                </li>
                <?php
                $count++;
            }
            ?>
    </ul>
    <?php } 
    endif;
    ?>
    <?php do_action( 'cth_listing_card_content' ); ?>
    <?php if( $hide_footer != 'yes' ): ?>
    <div class="geodir-category-footer fl-wrap lcard-bot">
        <?php if( $show_price == 'yes' ){
            $lprice = get_post_meta( get_the_ID(), '_price', true );
        ?>
        <div class="geodir-opt-link">
            <div class="geodir-category-price"><?php echo sprintf(_x( 'Avg/Night <span>%s</span>', 'Lcard price', 'easybook-add-ons' ), easybook_addons_get_price_formated($lprice) ); ?></div>
        </div>
        <?php } ?>
        <div class="geodir-opt-list">
            
            <?php if($hide_direction != 'yes' ):
            $latitude = get_post_meta( get_the_ID(), '_cth_latitude', true );
            $longitude = get_post_meta( get_the_ID(), '_cth_longitude', true ); ?>
            <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo esc_attr( $latitude ); ?>,<?php echo esc_attr( $longitude ); ?>" class="geodir-js-booking"><i class="fal fa-exchange"></i><span class="geodir-opt-tooltip"><?php _e( 'Find Directions', 'easybook-add-ons' ); ?></span></a>
            <?php endif; ?>
            <?php if( $hide_bookmark != 'yes' ): ?>
            <div class="geodir-js-favorite_btn">
                <?php if(!is_user_logged_in()): ?>
                    <a href="#" class="save-btn logreg-modal-open" data-message="<?php esc_attr_e( 'Logging in first to save this listing.', 'easybook-add-ons' ); ?>"><i class="fal fa-heart"></i><span class="geodir-opt-tooltip"><?php _e( 'Save', 'easybook-add-ons' ); ?></span></a>
                <?php elseif( easybook_addons_already_bookmarked(get_the_ID()) ): ?>
                    <a href="javascript:void(0);" class="save-btn" data-id="<?php the_ID(); ?>"><i class="fas fa-heart"></i><span class="geodir-opt-tooltip"><?php _e( 'Saved', 'easybook-add-ons' ); ?></span></a>
                <?php else: ?>
                    <a href="#" class="save-btn bookmark-listing-btn" data-id="<?php the_ID(); ?>" ><i class="fal fa-heart"></i><span class="geodir-opt-tooltip"><?php _e( 'Save', 'easybook-add-ons' ); ?></span></a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if( $hide_view_map != 'yes' && easybook_addons_get_option('use_osm_map') !='yes' ): ?><a href="#" class="single-map-item"><i class="fal fa-map-marker-alt"></i><span class="geodir-opt-tooltip"><?php _e( 'On the map', 'easybook-add-ons' ); ?></span></a><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

</div>

