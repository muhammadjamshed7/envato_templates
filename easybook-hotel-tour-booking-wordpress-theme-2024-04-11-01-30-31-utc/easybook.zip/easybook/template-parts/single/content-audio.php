<?php
/* banner-php */
/**
 * Template part for displaying audio posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>
<!-- article> --> 
<article id="post-<?php the_ID(); ?>" <?php post_class('pos-single ptype-content-audio'); ?>> 
    <?php 
    if(easybook_get_option('single_featured' )): ?>
        <?php 
		if(get_post_meta(get_the_ID(), '_cth_embed_video', true)!=""){ ?>	
		    <div class="list-single-main-media fl-wrap">
		    	<?php
		    		$audio_url = get_post_meta(get_the_ID(), '_cth_embed_video', true);
					if(preg_match('/(.mp3|.ogg|.wma|.m4a|.wav)$/i', $audio_url )){
						$attr = array(
							'src'      => $audio_url,
							'loop'     => '',
							'autoplay' => '',
							'preload'  => 'none'
						);
						echo wp_audio_shortcode( $attr );
					}else{
				?>
					<div class="resp-audio">
						<?php echo wp_oembed_get(esc_url( $audio_url ) , array('height'=>'166') ); ?>
					</div>
				<?php } ?>
		    	
	        </div>
        <?php
        }elseif(has_post_thumbnail( )){ ?>
        <div class="list-single-main-media fl-wrap">
            <?php the_post_thumbnail('easybook-single-image',array('class'=>'respimg') ); ?>
        </div>
        <?php } 
        ?>
    <?php 
    endif; ?>
    <div class="list-single-main-items fl-wrap">
        <div class="list-single-main-item-title fl-wrap">
            <?php 
            the_title( '<h3 class="entry-title">', '</h3>' );
            easybook_edit_link( get_the_ID() );
            ?>
        </div>
        <?php the_content();?>
        <?php easybook_link_pages('post-single'); ?>
        <div class="clearfix"></div>
        <?php easybook_single_post_author(); ?>
        <?php easybook_single_post_metas(); ?>
        <?php easybook_single_post_tags(); ?>
        <span class="fw-separator"></span>
        <?php easybook_post_nav();?> 
    </div>
</article>
<!-- article end -->       
<span class="section-separator"></span>

