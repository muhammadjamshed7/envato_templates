<?php
/* banner-php */
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>
<!-- article> --> 
<article id="post-<?php the_ID(); ?>" <?php post_class('fl-wrap ptype-content fw-post'); ?>> 
    <?php 
	// Get the list of files
    $slider_images = get_post_meta( get_the_ID(), '_cth_post_slider_images', true);
    if( !empty($slider_images)&& easybook_get_option('blog_show_format', true ) && get_post_format( ) !== 'gallery' ){ ?>
	<div class="list-single-main-media fl-wrap">
		<div class="single-slider-wrapper fl-wrap">

			<div class="single-slider fl-wrap">
				<?php 
                foreach ( (array) $slider_images as $img_id => $img_url ) {
			        echo '<div class="slick-slide-item">';
			        	echo '<a href="' . esc_url( get_permalink() ) . '" class="blog-thumb-link">';
			        		echo wp_get_attachment_image($img_id, 'easybook-featured-image','',array('class'=>'respimgsss') );
			        	echo '</a>';
			        echo '</div>';
			    }
				?>
            </div>
            <div class="swiper-button-prev sw-btn"><i class="fa fa-long-arrow-left"></i></div>
            <div class="swiper-button-next sw-btn"><i class="fa fa-long-arrow-right"></i></div>
        </div>
    </div>
	<?php
	}elseif(has_post_thumbnail( )){ ?>
	<div class="list-single-main-media fl-wrap">
        <a href="<?php the_permalink( ); ?>" class="blog-thumb-link">
        	<?php the_post_thumbnail('easybook-featured-image',array('class'=>'respimg') ); ?>
        </a>
    </div>
	<?php } ?>
    <div class="list-single-main-items fl-wrap">
        <div class="list-single-main-item-title fl-wrap">
        	<?php 
			the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
			
			?>
        </div>
        <?php if(easybook_get_option('blog_post_format') ==='2'){
    			$excerpt = get_the_excerpt();
            	echo substr($excerpt, 0, 70);
            }else{
            	the_excerpt();
        	}
        ?>
        <?php easybook_link_pages(); ?>
		<?php easybook_list_post_author(); ?>
        <?php easybook_list_post_metas(); ?>
        <?php easybook_list_post_tags(); ?>
        <span class="fw-separator"></span>
        <div class="readmore-post"><a href="<?php the_permalink();?>" class="btn float-btn color-bg"><?php esc_html_e('Read more ','easybook' );?><i class="fal fa-angle-right"></i></a></div>
    </div>
</article>
<!-- article end -->       

