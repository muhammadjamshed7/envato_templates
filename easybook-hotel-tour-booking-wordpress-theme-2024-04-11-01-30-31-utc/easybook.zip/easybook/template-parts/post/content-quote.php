<?php
/* banner-php */
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>
<!-- article> --> 
<article id="post-<?php the_ID(); ?>" <?php post_class('fl-wrap ptype-content-quote fw-post'); ?>>
	<?php
	if(has_post_thumbnail( )){ ?>
	<div class="list-single-main-media fl-wrap">
        <a href="<?php the_permalink( ); ?>" class="blog-thumb-link">
        	<?php the_post_thumbnail('easybook-featured-image',array('class'=>'respimg') ); ?>
        </a>
    </div>
	<?php } ?>

    <div class="list-single-main-items fl-wrap">
        <div class="list-single-main-item-title fl-wrap">
        	<?php 
			the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
			easybook_edit_link( get_the_ID() );
			?>
        </div>
        <blockquote><?php if(easybook_get_option('blog_post_format') ==='2'){
    			$excerpt = get_the_excerpt();
            	echo substr($excerpt, 0, 70);
            }else{
            	the_excerpt();
        	}
        ?></blockquote>
        <?php easybook_link_pages(); ?>
		<?php easybook_list_post_author(); ?>
        <?php easybook_list_post_metas(); ?>
        <?php easybook_list_post_tags(); ?>
        <span class="fw-separator"></span>
        <div class="readmore-post"><a href="<?php the_permalink();?>" class="btn float-btn color-bg"><?php esc_html_e('Read more ','easybook' );?><i class="fal fa-angle-right"></i></a></div>
    </div>
</article>
<!-- article end -->       
