<?php
/* banner-php */
/**
 * The header for our theme 
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials 
 *
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg" itemscope> 
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="//gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php 
if(easybook_get_option('show_loader', true ) ) : 
    $loader_icon = easybook_get_option('loader_icon');
?>
    <!--loader-->
    <div class="loader-wrap">
        <div class="loader-inner">
        <?php if(!empty($loader_icon)): ?>
            <div class="loader-icon-img">
                <?php echo wp_get_attachment_image( $loader_icon, 'full', false, array('class'=>'no-lazy')); ?> 
            </div>
            <div class="ldicon-pulse"></div>
        <?php else: ?>
            <div class="pin">
                <div class="pulse"></div>
            </div>
            
        <?php endif; ?>
        </div>
    </div>
    <!--loader end-->
    <div id="main-theme">
<?php else :?>
    <div id="main-theme" class="is-hide-loader">
<?php endif;?>

        <!-- header-->
        <header id="masthead" class="easybook-header main-header dark-header fs-header sticky">
            <?php
            if(easybook_get_option( 'header_info'  ) != ''): ?>
            <div class="header-contacts">
                <?php echo wp_kses_post( easybook_get_option( 'header_info') ); ?>
            </div>
            <?php endif;?>
            <div class="header-top fl-wrap">
                <div class="container">
                    <div class="logo-holder">
                        <?php 
                        if(has_custom_logo()) the_custom_logo(); 
                        else echo '<a class="custom-logo-link logo-text" href="'.esc_url( home_url('/' ) ).'"><h2>'.get_bloginfo( 'name' ).'</h2></a>'; 
                        ?>
                    </div>
                    <?php echo do_shortcode( easybook_check_shortcode('[easybook_submit_button]', 'easybook_submit_button') );?>
                    <?php 
                        if(!is_user_logged_in()){
                            echo do_shortcode( easybook_check_shortcode('[easybook_login style="'.easybook_get_option('user_menu_style').'"]', 'easybook_login') );
                        };   
                    ?>
                    <?php 
                        if(is_active_sidebar('sidebar-lang')){
                            dynamic_sidebar('sidebar-lang');
                    } ?>
                    <?php echo do_shortcode( easybook_check_shortcode('[currency_list]', 'currency_list') );?>
                </div>
            </div>
            <div class="header-inner fl-wrap">
                <div class="container">
                    <?php if(easybook_get_option('show_fixed_search', true ) && shortcode_exists('easybook_search_header_top')):
                        $op_text = esc_attr__( 'Search', 'easybook' ); 
                        $cl_text = esc_attr__( 'Close', 'easybook' ); 
                        ?>
                        <div class="show-search-button" data-optext="<?php echo $op_text; ?>" data-cltext="<?php echo $cl_text; ?>"><span><?php echo $op_text;?></span> <i class="fa fa-search"></i> </div>
                    <?php endif; ?>
                    <?php  $listing_bookmarks = get_user_meta( get_current_user_id(), '_cth_listing_bookmarks', true );
                        $cout_whish = (!empty($listing_bookmarks) && $listing_bookmarks != '')? count($listing_bookmarks) : '0';
                        if(shortcode_exists('easybook_wishlist')) {
                     ?>
                        <div class="wishlist-link"><i class="fal fa-heart"></i><span class="wl_counter"><?php 
                        echo esc_html($cout_whish); ?></span></div>
                    <?php 
                        }   
                    ?>
                    <?php 
                        $head_carts = easybook_get_header_cart_link();
                        if (  !empty($head_carts) ) {
                        ?>
                        <div class="attr-nav">
                            <ul>
                                <li>
                                    <a href="#" class="cart-link">
                                        <i class="fal fa-shopping-bag"></i>
                                        <span class="cart-count"><?php echo esc_html($head_carts['count'] );?></span>
                                    </a>
                                <?php if(easybook_get_option('show_mini_cart')): ?>
                                    <ul class="cart-list">
                                        <li><div class="widget_shopping_cart_content"></div></li>
                                    </ul>
                                <?php endif;?>
                                </li>
                            </ul>
                        </div>
                    <?php 
                        }
                    ?>
                    
                    <?php 
                        if(is_user_logged_in()){
                            echo do_shortcode( easybook_check_shortcode('[easybook_login style="'.easybook_get_option('user_menu_style').'"]', 'easybook_login') );
                        };  ?>
                    <div class="home-btn"><a href="<?php echo esc_url( home_url('/' ) ); ?>"><i class="fa fa-home"></i></a></div>
                    <!-- nav-button-wrap-->
                    <div class="nav-button-wrap">
                        <div class="nav-button">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                    <!-- nav-button-wrap end-->
                    <?php if ( has_nav_menu( 'top' ) ) : ?>
                        <!--  .nav-holder -->
                        <div class="nav-holder main-menu">
                            <?php get_template_part( 'template-parts/navigation/navigation', 'top' ); ?>
                        </div><!-- .nav-holder -->
                    <?php endif; ?>
                    
                    <!-- wishlist-wrap-->            
                    <?php echo do_shortcode( easybook_check_shortcode('[easybook_wishlist]', 'easybook_wishlist') );?>
                    <!-- wishlist-wrap end--> 
                </div>
            </div>
            <?php 
            if(easybook_get_option('show_fixed_search', true )) : ?>     
            <?php echo do_shortcode( easybook_check_shortcode('[easybook_search_header_top]', 'easybook_search_header_top') );?>
            <?php endif;?>
        </header>
        <!--  header end -->
        <!--  wrapper  -->
        <div id="wrapper">
            <!-- Content-->
            <div class="content">

                
