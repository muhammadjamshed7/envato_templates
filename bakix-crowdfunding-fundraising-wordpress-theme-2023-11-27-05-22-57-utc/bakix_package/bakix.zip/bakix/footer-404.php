<?php $bakix_redux_demo = get_option('redux_demo');?>

	
</div>
<?php wp_footer(); ?>
</body>
</html>