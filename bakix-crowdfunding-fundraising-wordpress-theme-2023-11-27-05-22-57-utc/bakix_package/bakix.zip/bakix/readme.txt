/*
    Theme Name: Bakix
	Theme URI: http://shtheme.com/demosd/bakix
	Author: Basictheme
	Author URI: https://themeforest.net/user/basictheme
    Release Date: 03 May 2018
    Requirements: WordPress 4.0 or higher, PHP 5
    Compatibility: WordPress 4.9.1
    Tags: web app
    Last Update Date: 03 May 2018
*/

/**** Readme ****/

"Please backup your theme pack files at first before you update the theme into the latest version"


2018.05.03 - version 1.0.0
- First release.
