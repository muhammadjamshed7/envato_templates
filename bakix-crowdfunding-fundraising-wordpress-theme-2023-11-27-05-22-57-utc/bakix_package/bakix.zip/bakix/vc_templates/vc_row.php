<?php
$output = $el_class = $bg_image = $bg_color = $bg_image_repeat = $font_color = $padding = $margin_bottom = $css = '';
extract(shortcode_atts(array(
    'el_class'        => '',
    'bg_image'        => '',
    'bg_image_repeat' => '',
    'padding'         => '',
    'margin_bottom'   => '',
    'css' => '',
    'ses_title'=>'',
    'type_row' => '',
    'ses_subtitle' => '',
    'ses_image' => '',
    'ses_image2' => '',
    'ses_image3' => '',
    'image'=>'',
    'ses_text_btn'=>'',

), $atts));

wp_enqueue_script( 'wpb_composer_front_js' );

$el_class = $this->getExtraClass($el_class);
$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ''. ( $this->settings('base')==='vc_row_inner' ? 'vc_inner ' : '' ) . $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
$style = $this->buildStyle($bg_image, $bg_color, $bg_image_repeat, $font_color, $padding, $margin_bottom);
$images = wp_get_attachment_image_src($ses_image,'');
if($type_row == 'type2'){
    $output .= wpb_js_remove_wpautop($content);
    $output .= $this->endBlockComment('row');

}elseif($type_row == 'features'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="features-area pt-120 pb-80">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9 col-lg-8">
                            <div class="section-title mb-65">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                            <div class="section-link mb-80 text-lg-right">
                                <a class="btn-border" href="'.$ses_link.'">'.$ses_text_btn.'</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </section>';

}elseif($type_row == 'how_work'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="how-works-area pt-120 pb-120">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9 col-lg-9">
                            <div class="section-title mb-55">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 d-none d-xl-block">
                            <div class="section-link mb-80 text-right">
                                <a class="btn-border btn-theme popup-video" href="'.$ses_link.'"><i class="fas fa-play"></i> '.$ses_text_btn.'</a>
                            </div>
                        </div>
                    </div>
                    <div class="row process-pareent">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
            </div>
          </section>';          

}elseif($type_row == 'blog'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="news-area grey-bg pt-120 pb-120">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9 col-lg-8">
                            <div class="section-title mb-65">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                            <div class="section-link mb-65 text-right">
                                <a class="btn-border" href="'.$ses_link.'">'.$ses_text_btn.'</a>
                            </div>
                        </div>
                    </div>';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
          </section>';

}elseif($type_row == 'banner_style_2'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="hero-area ">
                <div class="hero-slider-area" data-background="'.esc_url($images[0]).'">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
          </section>'; 

}elseif($type_row == 'banner_style_3'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="hero-area ">
                <div class="hero-slider-area" >
                    <div class="row no-gutters">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </section>';          

}elseif($type_row == 'blog_style_2'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="news-area grey-bg pt-120 pb-90">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9 col-lg-8">
                            <div class="section-title mb-65">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                            <div class="section-link mb-65 text-right">
                                <a class="btn-border" href="'.$ses_link.'">'.$ses_text_btn.'</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </section>'; 

}elseif($type_row == 'form_subcribe'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $images2 = wp_get_attachment_image_src($ses_image2,'');
    $images3 = wp_get_attachment_image_src($ses_image3,'');
    $output .='<section class="newsletter-area pos-relative event-bg pt-120 pb-120" data-background="'.esc_url($images[0]).'">
                <div class="letter-shape letter-s1 bounce-animate"><img src="'.esc_url($images2[0]).'"  ></div>
                <div class="letter-shape letter-s2 bounce-animate"><img src="'.esc_url($images3[0]).'"  ></div>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-5 col-lg-5">
                            <div class="section-title white-text">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7">
                            <div class="subscribe-form subscribe-form-2">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </div>
      </div>
  </section>';
}elseif($type_row == 'brand'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="brand-area pt-110 pb-120" data-background="'.esc_url($images[0]).'">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="brand-heading text-center mb-80">
                                <h3>'.$ses_title.'</h3>
                            </div>
                            <div class="brand-active owl-carousel">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </div>
      </div>
  </section>';

}elseif($type_row == 'team'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="team-area pt-120 pb-90">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-12">
                            <div class="section-title text-center mb-60">
                                <p><span></span> '.$ses_title.' </p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </section>'; 

}elseif($type_row == 'team_2'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="team-area pt-120 pb-90">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-9 col-lg-8">
                            <div class="section-title mb-65">
                                <p><span></span> '.$ses_title.'</p>
                                <h1>'.$ses_subtitle.'</h1>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                            <div class="section-link mb-80 text-lg-right">
                                <a class="btn-border" href="'.$ses_link.'">'.$ses_text_btn.'</a>
                            </div>
                        </div>
                    </div>
                    <div class="row">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
              </div>
          </section>';          

}elseif($type_row == 'contact'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="contact-area pt-120 pb-90" data-background="'.esc_url($images[0]).'">
                <div class="container">
                    <div class="row">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
            </div>
        </section>';
}elseif($type_row == 'contact_form'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="contact-form-area">
                <div class="container">
                    <div class="form-wrapper grey-bg">
                        <div class="row align-items-center">
                            <div class="col-xl-8 col-lg-8">
                                <div class="section-title mb-55">
                                    <p><span></span> '.$ses_title.'</p>
                                    <h1>'.$ses_subtitle.'</h1>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-3 d-none d-xl-block ">
                                <div class="section-link mb-80 text-right">
                                    <a class="btn-border btn-theme" href="'.$ses_link.'"><i class="fas fa-phone"></i> '.$ses_text_btn.'</a>
                                </div>
                            </div>
                        </div>
                        <div class="contact-form">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='<p class="ajax-response text-center"></p>
            </div>
        </div>
    </div>
</section>';          

}elseif($type_row == 'testimonial'){
    $images = wp_get_attachment_image_src($ses_image,'');
    $output .='<section class="big-team-area">
                <div class="big-image">
                    <img src="'.esc_url($images[0]).'"  >
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="testimonial-active owl-carousel theme-bg">';
    $output .= wpb_js_remove_wpautop($content);
    $output .=''.$this->endBlockComment('row');
    $output .='</div>
            </div>
        </div>
    </div>
</section>';

}else{
    $output .= wpb_js_remove_wpautop($content);
    $output .= $this->endBlockComment('row');

}
echo wp_specialchars_decode(esc_attr($output),ENT_QUOTES);