<?php
/**
 * The template for displaying 404 pages (Not Found)
 */
    $bakix_redux_demo = get_option('redux_demo');
    get_header(); 
?> 
<section class="error-section">
    <div class="auto-container">
        <div class="inner-section">
            <h1><?php if(isset($bakix_redux_demo['404_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['404_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Error 404', 'bakix' );
                                    }
                                    ?></h1>
            <h3><?php if(isset($bakix_redux_demo['404_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['404_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Sorry we are not finding anything', 'bakix' );
                                    }
                                    ?></h3>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="theme-btn btn-style-one"><?php if(isset($bakix_redux_demo['404_button'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['404_button']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Go back home', 'bakix' );
                                    }
                                    ?></a>
            <div class="copyright"><?php if(isset($bakix_redux_demo['404_text_footer'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['404_text_footer']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '2019 &copy; All rights reserved by Basictheme', 'bakix' );
                                    }
                                    ?></div>
        </div>
    </div>
</section>
<?php
get_footer('404'); ?> 
