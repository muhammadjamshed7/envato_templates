<?php
   $bakix_redux_demo = get_option('redux_demo');
   get_header(); 
?>
<?php 
    while (have_posts()): the_post();
    get_template_part( 'content', get_post_format() );
?>
<?php $single_facebook = get_post_meta(get_the_ID(),'_cmb_single_facebook', true); ?>
<?php $single_twitter = get_post_meta(get_the_ID(),'_cmb_single_twitter', true); ?>
<?php $single_google = get_post_meta(get_the_ID(),'_cmb_single_google', true); ?>
<?php $single_instagram = get_post_meta(get_the_ID(),'_cmb_single_instagram', true); ?>
<?php $single_vimeo = get_post_meta(get_the_ID(),'_cmb_single_vimeo', true); ?>
<?php $audio_link = get_post_meta(get_the_ID(),'_cmb_audio_link', true); ?>
<?php $video_link = get_post_meta(get_the_ID(),'_cmb_video_link', true); ?>
<?php $img_gallery_1 = get_post_meta(get_the_ID(),'_cmb_img_gallery_1', true); ?>
<?php $img_gallery_2 = get_post_meta(get_the_ID(),'_cmb_img_gallery_2', true); ?>
<?php $img_gallery_3 = get_post_meta(get_the_ID(),'_cmb_img_gallery_3', true); ?>
<?php $facebook_user = get_the_author_meta('facebook');?>
<?php $twitter_user = get_the_author_meta('twitter');?>
<?php $behance_user = get_the_author_meta('behance');?>
<?php $youtube_user = get_the_author_meta('youtube');?>
<?php $vimeo_user = get_the_author_meta('vimeo');?>

<!-- page title start -->
<main>
  <?php if(isset($bakix_redux_demo['blog_details_image_banner_image']['url']) && $bakix_redux_demo['blog_details_image_banner_image']['url'] != ''){?>
  <section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_url($bakix_redux_demo['blog_details_image_banner_image']['url']); ?>">
  <?php }else{?>
  <section class="page-title-area pt-150 pb-150" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/page-banner.jpg">
  <?php } ?>
      <div class="container">
          <div class="row">
              <div class="col-xl-12 col-lg-12">
                  <div class="page-title page-title-white">
                      <h2><?php the_title();?></h2>
                  </div>
              </div>
          </div>
      </div>
  </section>
    <!-- page-title-area end -->

    <!-- blog-area start -->
    <div class="blog-area blog-post pt-120 pb-80">
        <div class="container">
            <div class="row">
                <?php if ( is_active_sidebar( 'sidebar-1' ) ){ ?>
                <div class="col-lg-8">
                <?php }else{ ?>
                <div class="col-lg-12">
                <?php } ?>                          
                    <article class="postbox post format-image mb-40">
                        <?php if ( has_post_thumbnail() ) { ?>
                        <div class="postbox__thumb mb-35">
                          
                              <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="blog image" />
                          
                        </div>
                        <?php } ?>
                        <div class="postbox__text bg-none">
                            <div class="post-meta mb-15">
                              <?php if ( is_sticky() )
                                           echo '<span class="featured-post">' . esc_html__( 'Sticky', 'bakix' ) . '</span>';
                                           ?>
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><i class="far fa-user"></i> <?php the_author_posts_link(); ?></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <div class="post-text mb-20">
                                <?php the_content(); ?>
                                <?php wp_link_pages( array(
                                    'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'bakix' ),
                                    'after'       => '</div>',
                                    'link_before' => '<span class="page-number">',
                                    'link_after'  => '</span>',
                                ) ); ?> 
                            </div>
                            <div class="row mt-50">
                                    <div class="blog-post-tag">
                                        <?php echo get_the_tag_list(); ?>
                                    </div>
                            </div>
                        </div>
                        <?php comments_template();?>
                    </article>
                </div>
                <?php if ( is_active_sidebar( 'sidebar-1' ) ){ ?>
                <div class="col-lg-4">
                    <?php get_sidebar();?>
                </div>  
                <?php }else{ ?>
                <?php } ?>
            </div>
        </div>
    </div>     
    <!-- blog-area end -->
<?php endwhile; ?>
    <!-- FOOTER -->
<?php
    get_footer('home2');
?>