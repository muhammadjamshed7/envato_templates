<?php
   $bakix_redux_demo = get_option('redux_demo');
   get_header('home1'); 
?>
<?php 
    while (have_posts()): the_post();
?>
<?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
<?php $end_day = get_post_meta(get_the_ID(),'_cmb_end_day', true); ?>
<?php $time = get_post_meta(get_the_ID(),'_cmb_time', true); ?>
<?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
<?php $type_event = get_post_meta(get_the_ID(),'_cmb_type_event', true); ?>
<?php $info2 = get_post_meta(get_the_ID(),'_cmb_info2', true); ?>
<?php $info1 = get_post_meta(get_the_ID(),'_cmb_info1', true); ?>
<?php $countdown = get_post_meta(get_the_ID(),'_cmb_countdown', true); ?>
<?php $start = get_post_meta(get_the_ID(),'_cmb_start', true); ?>
<?php $end = get_post_meta(get_the_ID(),'_cmb_end', true); ?>
<?php $tim = get_post_meta(get_the_ID(),'_cmb_tim', true); ?>

<main>
    <!-- page-title-area start -->
    <?php if(isset($bakix_redux_demo['single_event_image']['url']) && $bakix_redux_demo['single_event_image']['url'] != ''){?>
      <section class="page-title-area pt-320 pb-140" data-background="<?php echo esc_url($bakix_redux_demo['single_event_image']['url']); ?>">
      <?php }else{?>
      <section class="page-title-area pt-320 pb-140" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/breadcumb.jpg">
      <?php } ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="page-title page-title-white text-center">
                        <h2><?php if(isset($bakix_redux_demo['single_event_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['single_event_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Event Details', 'bakix' );
                                    }
                                    ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="fund-area pos-relative pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="event-time-wrapper mb-30">
                        <?php if ( has_post_thumbnail() ) { ?>
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"   />
                        <?php } ?>
                        <div class="event-count">
                            <ul class="pb-10">
                                <li>
                                    <h3><?php echo esc_attr($start);?></h3>
                                    <span><?php echo wp_specialchars_decode(esc_attr($start_day));?></span>
                                </li>
                                <li>
                                    <h3><?php echo esc_attr($end);?></h3>
                                    <span><?php echo wp_specialchars_decode(esc_attr($end_day));?></span>
                                </li>
                                <li>
                                    <h3><?php echo esc_attr($tim);?></h3>
                                    <span><?php echo wp_specialchars_decode(esc_attr($time));?></span>
                                </li>
                            </ul>
                            <div class="event-timer">
                                <div class="d-sm-flex justify-content-between pt-40" data-countdown="<?php echo esc_attr($countdown);?>"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="event-day-time pl-15">
                        <div class="section-title mb-35">
                            <p><span></span> <?php echo esc_attr($type_event);?></p>
                            <h1><?php the_title();?></h1>
                        </div>
                        <ul class="event-place pt-35 pb-15 mb-30">
                            <li><?php echo wp_specialchars_decode(esc_attr($info1));?></li>
                            <li><?php echo wp_specialchars_decode(esc_attr($info2));?></li>
                        </ul>
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- cta-area start -->
    <?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    <!-- cta-area end -->

</main>
<?php endwhile; ?>
<?php
    get_footer();
?>