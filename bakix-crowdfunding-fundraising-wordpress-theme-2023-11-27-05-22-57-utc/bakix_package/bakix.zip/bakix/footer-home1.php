<?php $bakix_redux_demo = get_option('redux_demo');?> 


<footer data-background="<?php echo esc_url($bakix_redux_demo['footer_home1_background']['url']); ?>">
            <!-- brand-area start -->
            <div class="brand-area pt-100 pb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <?php if ( is_active_sidebar( 'footer-area-1' ) ) : ?>
                                <?php dynamic_sidebar( 'footer-area-1' ); ?>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- brand-area end -->
            <div class="footer-area pb-40">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-2 col-lg-3 col-md-4">
                            <div class="footer-widget mb-40">
                                <div class="footer-logo mb-25">
                                    <?php if(isset($bakix_redux_demo['footer_logo']['url']) && $bakix_redux_demo['footer_logo']['url'] != ''){ ?>
                                      <img src="<?php echo esc_url($bakix_redux_demo['footer_logo']['url']); ?>"  >
                                      <?php }else{ ?>
                                          <img src="<?php echo get_template_directory_uri();?>/assets/img/logo/footer-logo.png"  >
                                      <?php } ?>
                                </div>
                                <div class="social-icon">
                                    <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_fb']));?>"><i class="fab fa-facebook-f"></i></a>
                                    <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_tw']));?>"><i class="fab fa-twitter"></i></a>
                                    <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_be']));?>"><i class="fab fa-behance"></i></a>
                                    <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_lin']));?>"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_yt']));?>"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-4">
                            <div class="footer-widget mb-40">
                                <?php if ( is_active_sidebar( 'footer-area-5' ) ) : ?>
                                <?php dynamic_sidebar( 'footer-area-5' ); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-3 col-md-4">
                            <div class="footer-widget mb-40">
                                <?php if ( is_active_sidebar( 'footer-area-3' ) ) : ?>
                                <?php dynamic_sidebar( 'footer-area-3' ); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-3 col-md-4 d-lg-none d-xl-block">
                            <div class="footer-widget mb-40">
                                <?php if ( is_active_sidebar( 'footer-area-4' ) ) : ?>
                                <?php dynamic_sidebar( 'footer-area-4' ); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="footer-widget mb-40">
                                <h4 class="footer-title"><?php if(isset($bakix_redux_demo['footer_news'])){?>
                                            <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['footer_news']));?>
                                            <?php }else{?>
                                            <?php echo esc_html__( 'News Feeds', 'bakix' );
                                            }
                                            ?></h4>
                                <ul class="widget-latest-post">
                                    <?php  $args = array(    
                                        'paged' => $paged,
                                        'post_type' => 'post',
                                        'posts_per_page' => 3,
                                        );
                                    $wp_query = new WP_Query($args);
                                    while (have_posts()): the_post(); ?>
                                    <?php $featured_image_2 = get_post_meta(get_the_ID(),'_cmb_featured_image_2', true); ?>
                                    <li>
                                        <div class="widget-thumb">
                                            <a href="<?php the_permalink();?>"><img src="<?php echo esc_attr($featured_image_2);?>"  ></a>
                                        </div>
                                        <div class="widget-content">
                                            <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                            <span><?php the_time(get_option( 'date_format' ));?></span>
                                        </div>
                                    </li>
                                    <?php endwhile; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-area">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="copyright-text text-center">
                                <p><?php echo esc_html__( 'Copyright All Right Reserved By SHTheme - 2019', 'bakix' );?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
<?php wp_footer(); ?>
</body>
</html>