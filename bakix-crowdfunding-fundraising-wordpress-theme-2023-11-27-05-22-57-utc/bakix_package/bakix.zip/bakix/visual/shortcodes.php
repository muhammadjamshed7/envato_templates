<?php 
$textdoimain = 'bakix';
$bakix_redux_demo = get_option('redux_demo');

global $pre_text;
$pre_text = 'VG ';

add_shortcode('banner_style1', 'banner_style1_func');
function banner_style1_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image2'=>'',
     'image'=>'',
     'title'=>'',
     'subtitle'=>'',
     'price1'=>'',
     'price2'=>'',
     'text1'=>'',
     'text2'=>'',
     'percent'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    $images2 = wp_get_attachment_image_src($image2,'');
    ?>
    <section class="hero-area ">
        <div class="hero-height" data-background="<?php echo (esc_url($images[0]));?>">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-10 offset-lg-1 offset-xl-2">
                        <div class="hero text-center pt-280">
                            <div class="hero__caption">
                                <p><?php echo esc_attr($subtitle)?></p>
                                <h1><?php echo wp_specialchars_decode(esc_attr($title));?></h1>
                            </div>
                            <div class="hero-progress">
                                <div class="progress">
                                    <div class="progress-bar w-<?php echo esc_attr($percent)?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <div class="payment-count mt-20 fix">
                                    <div class="count f-left text-left">
                                        <h2><?php echo esc_attr($price1)?></h2>
                                        <span><?php echo esc_attr($text1)?></span>
                                    </div>
                                    <div class="count f-right text-right">
                                        <h2><?php echo esc_attr($price2)?></h2>
                                        <span><?php echo esc_attr($text2)?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-img-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-10 offset-xl-1">
                        <div class="hero__img bounce-animate  text-center">
                            <img src="<?php echo (esc_url($images2[0]));?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('features', 'features_func');
function features_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'title'=>'',
     'subtitle'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="col-xl-4 col-lg-4 col-md-6">
        <div class="features text-center mb-40">
            <div class="features__icon mb-50">
                <img src="<?php echo (esc_url($images[0]));?>" alt="">
            </div>
            <div class="features__caption">
                <h2><?php echo esc_attr($title)?></h2>
                <p><?php echo esc_attr($subtitle)?></p>
            </div>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('how_work', 'how_work_func');
function how_work_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'title'=>'',
     'number'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="col-xl-4 col-lg-4">
        <div class="work-process text-center">
            <div class="process-no mb-20">
                <span class="border-line"><?php echo esc_attr($number)?></span>
            </div>
            <div class="process-content">
                <h3><?php echo esc_attr($title)?></h3>
            </div>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('blog', 'blog_func');
function blog_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'number'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <?php 
        $args = array(   
                    'post_type' => 'post',   
                    'paged' => $paged,
                    'posts_per_page' => $number,
                    'order' => $orderpost,
                    'orderby' => $orderby, 
                );  
                $wp_query = new WP_Query($args);
                $i = 1;
                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                $i++;
                $cates = get_the_terms(get_the_ID(),'type');
                $cate_name ='';
                $cate_slug = '';
                      foreach((array)$cates as $cate){
            if(count($cates)>0){
                $cate_name .= $cate->name.'  ' ;
                $cate_slug .= $cate->slug .' ';     
                } 
                } 
    ?>
    <?php $featured_image_3 = get_post_meta(get_the_ID(),'_cmb_featured_image_3', true); ?>
    <div class="col-xl-6 col-lg-6">
        <div class="latest-news mb-30">
            <div class="news__thumb">
                <img src="<?php echo esc_attr($featured_image_3);?>" alt="">
            </div>
            <div class="news__caption">
                <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                <a class="news-link" href="<?php the_permalink();?>"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?> <i class="flaticon-right-arrow-1"></i></a>
            </div>
        </div>
    </div>
    <?php  endwhile;?> 
<?php  return ob_get_clean();
}

add_shortcode('blog_style_2', 'blog_style_2_func');
function blog_style_2_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'number'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <?php 
        $args = array(   
                    'post_type' => 'post',   
                    'paged' => $paged,
                    'posts_per_page' => $number,
                    'order' => $orderpost,
                    'orderby' => $orderby, 
                );  
                $wp_query = new WP_Query($args);
                $i = 1;
                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                $i++;
                $cates = get_the_terms(get_the_ID(),'type');
                $cate_name ='';
                $cate_slug = '';
                      foreach((array)$cates as $cate){
            if(count($cates)>0){
                $cate_name .= $cate->name.'  ' ;
                $cate_slug .= $cate->slug .' ';     
                } 
                } 
    ?>
    <?php $featured_image_3 = get_post_meta(get_the_ID(),'_cmb_featured_image_3', true); ?>
    <div class="col-xl-4 col-lg-4">
        <div class="latest-news mb-30">
            <div class="news__thumb-2">
            <a href="<?php the_permalink();?>"><img src="<?php echo esc_attr($featured_image_3);?>" alt=""></a>
            </div>
            <div class="news__caption-2 white-bg">
                <div class="news-meta mb-15">
                    <span><a href="#"><?php the_author_posts_link(); ?></a></span>
                    <span><?php the_time(get_option( 'date_format' ));?></span>
                </div>
                <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(20)); 
                                }
                                ?></p>
            </div>
        </div>
    </div>
    <?php  endwhile;?> 
<?php  return ob_get_clean();
}

add_shortcode('banner_style_2', 'banner_style_2_func');
function banner_style_2_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'percent'=>'',
     'image'=>'',
     'title'=>'',
     'subtitle'=>'',
     'price1'=>'',
     'price2'=>'',
     'text1'=>'',
     'text2'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="single-slider pt-360">
        <div class="container">
            <div class="row">
                <div class="col-xl-7 col-lg-10">
                    <div class="hero hero-slider">
                        <div class="hero__caption">
                            <p data-animation="fadeInLeft" data-delay=".2s"><?php echo esc_attr($title)?></p>
                            <h1 data-animation="fadeInLeft" data-delay=".4s"><?php echo wp_specialchars_decode(esc_attr($subtitle));?></h1>
                        </div>
                        <div class="hero-progress">
                            <div class="progress" data-animation="fadeInUp" data-delay=".6s">
                                <div class="progress-bar w-<?php echo esc_attr($percent)?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="payment-count mt-20 fix">
                                <div class="count f-left text-left" data-animation="fadeInUp" data-delay=".8s">
                                    <h2><?php echo esc_attr($price1)?></h2>
                                    <span><?php echo esc_attr($text1)?></span>
                                </div>
                                <div class="count f-right text-right" data-animation="fadeInUp" data-delay="1s">
                                    <h2><?php echo esc_attr($price2)?></h2>
                                    <span><?php echo esc_attr($text2)?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-5 d-none d-xl-block">
                    <div class="slide-img" data-animation="fadeInRight" data-delay="1.2s">
                        <img src="<?php echo (esc_url($images[0]));?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('features_banner', 'features_banner_func');
function features_banner_func($atts, $content = null){
    extract(shortcode_atts(array(
     'title'=>'',
     'percent'=>'',
     'link'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="col-xl-4 col-lg-4">
        <div class="popular-features mb-30">
            <div class="hero__caption">
                <h4><a href="<?php echo esc_attr($link)?>"><?php echo esc_attr($title)?></a></h4>
            </div>
            <div class="hero-progress">
                <div class="progress">
                    <div class="progress-bar theme-bg w-<?php echo esc_attr($percent)?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('brand', 'brand_func');
function brand_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="single-brand">
        <img src="<?php echo (esc_url($images[0]));?>" alt="">
    </div>
<?php  return ob_get_clean();
}

add_shortcode('banner_style_3', 'banner_style_3_func');
function banner_style_3_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'type'=>'type1',
     'image'=>'',
     'title'=>'',
     'image2'=>'',
     'image3'=>'',
     'link'=>'',
     'text_btn'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    $images2 = wp_get_attachment_image_src($image2,'');
    $images3 = wp_get_attachment_image_src($image3,'');
    ?>
    <?php if($type =='type1'){ ?>
    <div class="col-lg-6">
        <div class="slide-box d-flex align-items-center" data-background="<?php echo (esc_url($images[0]));?>">
            <div class="slide-box-content text-center">
                <div class="slide-icon mb-50">
                    <img src="<?php echo (esc_url($images2[0]));?>" alt="">
                </div>
                <div class="slide-text mb-30">
                    <h3><?php echo esc_attr($title)?></h3>
                </div>
                <div class="slide-box-btn">
                    <a href="<?php echo esc_attr($link)?>" class="btn"><?php echo esc_attr($text_btn)?></a>
                </div>
            </div>
        </div>
    </div>
    <?php } else {?>
    <div class="col-lg-6">
        <div class="slide-box d-flex align-items-center" data-background="<?php echo (esc_url($images[0]));?>">
            <div class="slide-box-content text-center">
                <div class="slide-icon mb-50">
                    <img src="<?php echo (esc_url($images2[0]));?>" alt="">
                </div>
                <div class="slide-text mb-30">
                    <h3><?php echo esc_attr($title)?></h3>
                </div>
                <div class="slide-box-btn">
                    <a href="<?php echo esc_attr($link)?>" class="btn btn-sign"><?php echo esc_attr($text_btn)?> <img src="<?php echo (esc_url($images3[0]));?>" alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
<?php  return ob_get_clean();
}

add_shortcode('banner_style_4', 'banner_style_4_func');
function banner_style_4_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'title'=>'',
     'home'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="page-title-area pt-320 pb-140" data-background="<?php echo (esc_url($images[0]));?>">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="page-title page-title-white text-center">
                        <h2><?php echo esc_attr($title)?></h2>
                        <div class="breadcrumb-list">
                            <ul>
                                <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_attr($home)?></a></li>
                                <li><?php echo esc_attr($title)?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('banner_style_5', 'banner_style_5_func');
function banner_style_5_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'title'=>'',
     'home'=>'',
     'subtitle'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="page-title-area pt-150 pb-150" data-background="<?php echo (esc_url($images[0]));?>">
        <div class="container">
            <div class="row">
                <div class="col-xl-7 col-lg-8">
                    <div class="page-title page-title-white">
                        <h2><?php echo esc_attr($title)?></h2>
                        <p class="pl-0"><?php echo esc_attr($subtitle)?></p>
                        <div class="breadcrumb-list">
                            <ul>
                                <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_attr($home)?></a></li>
                                <li><?php echo esc_attr($title)?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('contact', 'contact_func');
function contact_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'icon'=>'',
     'title'=>'',
     'info'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="col-xl-4 col-lg-4 col-md-4">
        <div class="contact text-center mb-30">
            <i class="fas <?php echo esc_attr($icon)?>"></i>
            <h3><?php echo esc_attr($title)?></h3>
            <?php echo wp_specialchars_decode(esc_attr($info));?>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('portfolio', 'portfolio_func');
function portfolio_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'number'=>'',
     'title'=>'',
     'subtitle'=>'',
     'link'=>'',
     'text_btn'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="causes-area grey-bg pt-120 pb-90">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-9 col-lg-9">
                <div class="section-title mb-65">
                    <p><span></span> <?php echo esc_attr($title)?></p>
                    <h1><?php echo esc_attr($subtitle)?></h1>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 d-none d-xl-block">
                <div class="section-link mb-65 text-right">
                    <a class="btn-border" href="<?php echo esc_attr($link)?>"><?php echo esc_attr($text_btn)?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="causes-tab">
                    <ul class="nav theme-bg text-center mb-75" id="myTab" role="tablist">
                        <?php 
                         $b = 0;
                            $categories = get_terms('type2');   
                             foreach( (array)$categories as $categorie){
                                $cat_name = $categorie->name;
                                $cat_slug = $categorie->slug;
                                $b++;
                        ?>
                        <?php if($b == 1){?>
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-controls="home" aria-selected="true"><?php echo esc_attr($cat_name);?></a>
                        </li>
                         <?php }else{?>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-controls="profile" aria-selected="false"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }?>
                        <?php } ?>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <?php 
                        $a = 0;
                            $categories = get_terms('type2');   
                             foreach( (array)$categories as $categorie){
                                $cat_name1 = $categorie->name;
                                $cat_slug1 = $categorie->slug;
                                $a++;
                                $class1 = '';
                                if($a == 1){
                                    $class1 = "show active";
                                }
                        ?>
                        <div class="tab-pane fade <?php echo $class1;?>" id="<?php echo esc_attr($cat_slug1);?>" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <?php 
                                    $args = array(   
                                                'post_type' => 'portfolio',   
                                                'paged' => $paged,
                                                'posts_per_page' => $number,
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'type2',
                                                        'field'    => 'slug',
                                                        'terms'    => $cat_slug1,
                                                    ),
                                                ),
                                            );  
                                            $wp_query = new WP_Query($args);
                                            $i = 1;
                                            while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                            $i++;
                                ?>
                                <?php $portfolio_image_2 = get_post_meta(get_the_ID(),'_cmb_portfolio_image_2', true); ?>
                                <?php $pfl_type = get_post_meta(get_the_ID(),'_cmb_pfl_type', true); ?>
                                <?php $pledged = get_post_meta(get_the_ID(),'_cmb_pledged', true); ?>
                                <?php $target = get_post_meta(get_the_ID(),'_cmb_target', true); ?>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="causes white-bg mb-30">
                                        <div class="causes__img">
                                            <img src="<?php echo esc_attr($portfolio_image_2);?>" alt="">
                                        </div>
                                        <div class="causes__caption">
                                            <div class="causes-tag mb-20">
                                                <a href="#"><?php echo wp_specialchars_decode(esc_attr($pfl_type));?></a>
                                            </div>
                                            <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                            <div class="causes-progress">
                                                <div class="progress">
                                                    <div class="progress-bar w-75" role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                                <div class="causes-count mt-15 fix">
                                                    <div class="count-number f-left text-left">
                                                        <?php echo wp_specialchars_decode(esc_attr($pledged));?>
                                                    </div>
                                                    <div class="count-number f-right text-right">
                                                        <?php echo wp_specialchars_decode(esc_attr($target));?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php  endwhile; ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php  return ob_get_clean();
}

add_shortcode('event', 'event_func');
function event_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'title'=>'',
     'subtitle'=>'',
     'link'=>'',
     'text_btn'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="event-area pos-relative event-bg pt-120 pb-120">
    <div class="event-shape spahe1 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p1.png" alt=""></div>
    <div class="event-shape spahe2 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p2.png" alt=""></div>
    <div class="event-shape spahe3 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p3.png" alt=""></div>
    <div class="event-shape spahe4 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p4.png" alt=""></div>
    <div class="event-shape spahe5 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p5.png" alt=""></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-9 col-lg-8">
                <div class="section-title white-text mb-65">
                    <p><span></span> <?php echo esc_attr($title)?> </p>
                    <h1><?php echo esc_attr($subtitle)?></h1>
                    
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                <div class="section-link mb-65 text-right">
                    <a class="btn-border btn-soft" href="<?php echo esc_attr($link)?>"><?php echo esc_attr($text_btn)?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="basic-tab">
                    <ul class="nav tab-menu justify-content-center mb-50" id="eventTab" role="tablist">
                        <?php 
                         $b = 0;
                            $categories = get_terms('type1');   
                             foreach( (array)$categories as $categorie){
                                $cat_name = $categorie->name;
                                $cat_slug = $categorie->slug;
                                $b++;
                        ?>
                        <?php if($b == 2){?>
                        <li class="nav-item">
                            <a class="nav-link active" id="profile-tabe" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                 aria-selected="false"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }else{?>

                        <li class="nav-item">
                            <a class="nav-link" id="home-tabe" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-selected="true"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }?>
                        <?php } ?>
                    </ul>
                    <div class="tab-content" id="emyTabContent">
                        <?php 
                        $a = 0;
                            $categories = get_terms('type1');   
                             foreach( (array)$categories as $categorie){
                                $cat_name1 = $categorie->name;
                                $cat_slug1 = $categorie->slug;
                                $a++;
                                $class1 = '';
                                if($a == 2){
                                    $class1 = "show active";
                                }
                        ?>
                            <div class="tab-pane fade <?php echo $class1;?>" id="<?php echo esc_attr($cat_slug1);?>" role="tabpanel">
                                <?php 
                                    $args = array(   
                                                'post_type' => 'event',   
                                                'paged' => $paged,
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'type1',
                                                        'field'    => 'slug',
                                                        'terms'    => $cat_slug1,
                                                    ),
                                                ),
                                            );  
                                            $wp_query = new WP_Query($args);
                                            $i = 1;
                                            while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                            $i++;
                                ?>
                                <?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
                                <?php $end_day = get_post_meta(get_the_ID(),'_cmb_end_day', true); ?>
                                <?php $time = get_post_meta(get_the_ID(),'_cmb_time', true); ?>
                                <?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
                                <?php $type_event = get_post_meta(get_the_ID(),'_cmb_type_event', true); ?>
                                <?php $info2 = get_post_meta(get_the_ID(),'_cmb_info2', true); ?>
                                <?php $info1 = get_post_meta(get_the_ID(),'_cmb_info1', true); ?>
                                <?php $countdown = get_post_meta(get_the_ID(),'_cmb_countdown', true); ?>
                                <?php $event_image_2 = get_post_meta(get_the_ID(),'_cmb_event_image_2', true); ?>
                                <div class="event-wrapper mb-40">
                                    <div class="row">
                                        <div class="col-lg-3 d-flex align-items-center">
                                            <div class="event-time">
                                                <div class="event-icon mb-20">
                                                    <img src="<?php echo esc_attr($event_image_2);?>" alt="">
                                                </div>
                                                <div class="event-time-text">
                                                    <h4><?php echo wp_specialchars_decode(esc_attr($time));?></h4>
                                                    <span><?php echo esc_attr($type_event);?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 d-flex align-items-center ">
                                            <div class="event-info">
                                                <h3><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
                                                <div class="event-meta mb-15">
                                                    <span><?php echo wp_specialchars_decode(esc_attr($info2));?></span>
                                                    <span><?php echo wp_specialchars_decode(esc_attr($info1));?></span>
                                                </div>
                                                <p><?php if(isset($bakix_redux_demo['event_excerpt'])){?>
                                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['event_excerpt'])); ?>
                                                <?php }else{?>
                                                <?php echo esc_attr(bakix_excerpt(20)); 
                                                }
                                                ?></p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 d-flex align-items-center justify-content-start justify-content-lg-end">
                                            <div class="event-btn">
                                                <a href="<?php the_permalink(); ?>" class="btn-circle"><?php if(isset($bakix_redux_demo['event_read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['event_read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Join Today', 'bakix' );
                                    }
                                    ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php  endwhile; ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php  return ob_get_clean();
}

add_shortcode('team', 'team_func');
function team_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'name'=>'',
     'info'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="col-lg-4 col-md-6">
        <div class="team mb-30">
            <div class="team__img">
                <img src="<?php echo (esc_url($images[0]));?>" alt="">
            </div>
            <div class="team__content text-center white-bg">
                <h4><a href="<?php echo esc_attr($link)?>"><?php echo esc_attr($name)?></a></h4>
                <span><?php echo esc_attr($info)?></span>
            </div>
        </div>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('popular_portfolio', 'popular_portfolio_func');
function popular_portfolio_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'title'=>'',
     'subtitle'=>'',
     'link'=>'',
     'text_btn'=>'',
     'number'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="causes-area grey-bg pt-120 pb-120">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-12">
                            <div class="section-title text-center mb-60">
                                <p><span></span> <?php echo esc_attr($title)?></p>
                                <h1><?php echo esc_attr($subtitle)?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php 
                            $args = array(   
                                        'post_type' => 'portfolio',   
                                        'paged' => $paged,
                                        'posts_per_page' => $number,
                                        'order' => $orderpost,
                                        'orderby' => $orderby, 
                                    );  
                                    $wp_query = new WP_Query($args);
                                    $i = 1;
                                    while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                    $i++;
                                    $cates = get_the_terms(get_the_ID(),'type2');
                        ?>
                        <?php $portfolio_image_2 = get_post_meta(get_the_ID(),'_cmb_portfolio_image_2', true); ?>
                        <?php $pfl_type = get_post_meta(get_the_ID(),'_cmb_pfl_type', true); ?>
                        <?php $pledged = get_post_meta(get_the_ID(),'_cmb_pledged', true); ?>
                        <?php $target = get_post_meta(get_the_ID(),'_cmb_target', true); ?>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="causes white-bg mb-30">
                                <div class="causes__img">
                                    <img src="<?php echo esc_attr($portfolio_image_2);?>" alt="">
                                </div>
                                <div class="causes__caption">
                                    <div class="causes-tag mb-20">
                                        <a href="#"><?php echo wp_specialchars_decode(esc_attr($pfl_type));?></a>
                                    </div>
                                    <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                    <div class="causes-progress">
                                        <div class="progress">
                                            <div class="progress-bar w-75" role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                                aria-valuemax="100"></div>
                                        </div>
                                        <div class="causes-count mt-15 fix">
                                            <div class="count-number f-left text-left">
                                                <?php echo wp_specialchars_decode(esc_attr($pledged));?>
                                            </div>
                                            <div class="count-number f-right text-right">
                                                <?php echo wp_specialchars_decode(esc_attr($target));?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php  endwhile; ?>
                    </div>
                    <div class="row mt-30">
                        <div class="col-xl-12">
                            <div class="section-link text-center">
                                <a class="btn-border" href="<?php echo esc_attr($link)?>"><?php echo esc_attr($text_btn)?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<?php  return ob_get_clean();
}

add_shortcode('about', 'about_func');
function about_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'title'=>'',
     'subtitle'=>'',
     'content1'=>'',
     'content2'=>'',
     'content3'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="about-area pt-120">
        <div class="container">
            <div class="row">
                <div class="col-xl-5">
                    <div class="section-title mb-25">
                        <p><span></span> <?php echo esc_attr($title)?></p>
                        <h1><?php echo esc_attr($subtitle)?></h1>
                    </div>
                    <div class="about-community mb-30">
                        <p><?php echo esc_attr($content1)?></p>
                    </div>
                </div>
                <div class="col-xl-7">
                    <div class="about-community-text mb-30">
                        <p><?php echo wp_specialchars_decode(esc_attr($content2));?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="overview text-center mt-90" data-background="<?php echo (esc_url($images[0]));?>">
                        <p><?php echo wp_specialchars_decode(esc_attr($content3));?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('video', 'video_func');
function video_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'image'=>'',
     'video'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="video-area">
        <div class="bakix-video">
            <img src="<?php echo (esc_url($images[0]));?>" alt="">
            <a class="popup-video" href="<?php echo esc_attr($video)?>"><i class="fas fa-play"></i></a>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('mission', 'mission_func');
function mission_func($atts, $content = null){
    extract(shortcode_atts(array(
     'image'=>'',
     'title'=>'',
     'subtitle'=>'',
     'content1'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <section class="mission-area pt-120 pb-90 ">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 d-lg-none d-xl-block">
                    <div class="mission-img mb-30">
                        <img src="<?php echo (esc_url($images[0]));?>" alt="">
                    </div>
                </div>
                <div class="col-xl-7">
                    <div class="mission-text mb-30">
                        <div class="section-title mb-30">
                            <p><span></span> <?php echo esc_attr($title)?></p>
                            <h1><?php echo esc_attr($subtitle)?></h1>
                        </div>
                        <p><?php echo wp_specialchars_decode(esc_attr($content1));?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php  return ob_get_clean();
}

add_shortcode('testimonial', 'testimonial_func');
function testimonial_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'quote'=>'',
     'name'=>'',
    ), $atts));
    ob_start();
    $images = wp_get_attachment_image_src($image,'');
    ?>
    <div class="testimonial-item text-center">
        <p><?php echo wp_specialchars_decode(esc_attr($quote));?></p>
        <span>- <?php echo esc_attr($name)?></span>
    </div>
<?php  return ob_get_clean();
}

add_shortcode('register_form', 'register_form_func');
function register_form_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'title'=>'',

    ), $atts));
    ob_start();
    ?>
    <div class="login-area pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="basic-login">
                        <h3 class="text-center mb-60"><?php echo esc_attr($title)?></h3>
                        <?php echo do_shortcode("[wpcrl_register_form]"); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php  return ob_get_clean();
}

add_shortcode('login_form', 'login_form_func');
function login_form_func($atts, $content = null){
    extract(shortcode_atts(array( 
     'title'=>'',
    ), $atts));
    ob_start();
    ?>
    <div class="login-area pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="basic-login">
                        <h3 class="text-center mb-60"><?php echo esc_attr($title)?></h3>
                        <?php echo do_shortcode("[wpcrl_login_form]"); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php  return ob_get_clean();
}