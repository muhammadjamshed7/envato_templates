<?php 
$textdoimain = 'bakix';
global $pre_text;

$pre_text = 'VG ';

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Banner Style 1", 'bakix'),
   "base" => "banner_style1",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Background Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image background from media library to do your signature.', 'clinkers' )
   ),
      array(
         'type' => 'attach_image',
         'heading' => __( 'Product Image', 'clinkers' ),
         'param_name' => 'image2',
         'value' => '',
         'description' => __( 'Select image background from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Value Bar", 'bakix'),
         "param_name" => "percent",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price 1", 'bakix'),
         "param_name" => "price1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text 1", 'bakix'),
         "param_name" => "text1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price 2", 'bakix'),
         "param_name" => "price2",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text 2", 'bakix'),
         "param_name" => "text2",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Banner Style 2", 'bakix'),
   "base" => "banner_style_2",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Value Bar", 'bakix'),
         "param_name" => "percent",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price 1", 'bakix'),
         "param_name" => "price1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text 1", 'bakix'),
         "param_name" => "text1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Price 2", 'bakix'),
         "param_name" => "price2",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text 2", 'bakix'),
         "param_name" => "text2",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Banner Style 3", 'bakix'),
   "base" => "banner_style_3",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'dropdown',
         'heading' => __( 'Type background', 'bakix' ),
         'param_name' => 'type',
         'value' => array(
            __( 'Left Banner', 'bakix' ) => 'type1',
            __( 'Right Banner', 'bakix' ) => 'type2',
         ),
         'description' =>__( 'Select field do you want Order.', 'bakix' )
   ),
      array(
         'type' => 'attach_image',
         'heading' => __( 'Background Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         'type' => 'attach_image',
         'heading' => __( 'Icon Image', 'clinkers' ),
         'param_name' => 'image2',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link", 'bakix'),
         "param_name" => "link",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text Button", 'bakix'),
         "param_name" => "text_btn",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         'type' => 'attach_image',
         'heading' => __( 'Icon Button', 'clinkers' ),
         'param_name' => 'image3',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Banner Style 4", 'bakix'),
   "base" => "banner_style_4",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Background Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image background from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Home Text", 'bakix'),
         "param_name" => "home",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Banner Style 5", 'bakix'),
   "base" => "banner_style_5",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Background Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image background from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Home Text", 'bakix'),
         "param_name" => "home",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Features", 'bakix'),
   "base" => "features",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array(
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ), 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."How Work", 'bakix'),
   "base" => "how_work",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number", 'bakix'),
         "param_name" => "number",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Blog Style 1", 'bakix'),
   "base" => "blog",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number of posts", 'bakix'),
         "param_name" => "number",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Blog Style 2", 'bakix'),
   "base" => "blog_style_2",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number of posts", 'bakix'),
         "param_name" => "number",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Features Banner", 'bakix'),
   "base" => "features_banner",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array(
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Value Bar", 'bakix'),
         "param_name" => "percent",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link", 'bakix'),
         "param_name" => "link",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
} 

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Brand", 'bakix'),
   "base" => "brand",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ), 
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Contact", 'bakix'),
   "base" => "contact",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Icon", 'bakix'),
         "param_name" => "icon",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Info", 'bakix'),
         "param_name" => "info",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Portfolio", 'bakix'),
   "base" => "portfolio",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'bakix'),
         "param_name" => "link",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text Button", 'bakix'),
         "param_name" => "text_btn",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number of portfolio", 'bakix'),
         "param_name" => "number",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Popular Portfolio", 'bakix'),
   "base" => "popular_portfolio",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'bakix'),
         "param_name" => "link",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text Button", 'bakix'),
         "param_name" => "text_btn",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Number of portfolio", 'bakix'),
         "param_name" => "number",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Event", 'bakix'),
   "base" => "event",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Button", 'bakix'),
         "param_name" => "link",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Text Button", 'bakix'),
         "param_name" => "text_btn",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Team", 'bakix'),
   "base" => "team",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Avatar', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Name", 'bakix'),
         "param_name" => "name",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Info", 'bakix'),
         "param_name" => "info",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."About", 'bakix'),
   "base" => "about",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content 1", 'bakix'),
         "param_name" => "content1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content 2", 'bakix'),
         "param_name" => "content2",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content 3", 'bakix'),
         "param_name" => "content3",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Video", 'bakix'),
   "base" => "video",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image Video', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Link Video", 'bakix'),
         "param_name" => "video",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Mission", 'bakix'),
   "base" => "mission",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         'type' => 'attach_image',
         'heading' => __( 'Image', 'clinkers' ),
         'param_name' => 'image',
         'value' => '',
         'description' => __( 'Select image from media library to do your signature.', 'clinkers' )
   ),
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Subtitle", 'bakix'),
         "param_name" => "subtitle",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Content", 'bakix'),
         "param_name" => "content1",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Testimonial", 'bakix'),
   "base" => "testimonial",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Name", 'bakix'),
         "param_name" => "name",
         "value" => "",
         "description" => __("", 'bakix')
   ),
      array(
         "type" => "textarea",
         "holder" => "div",
         "class" => "",
         "heading" => __("Quote", 'bakix'),
         "param_name" => "quote",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Register Form", 'bakix'),
   "base" => "register_form",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

if(function_exists('vc_map')){
   vc_map( array(
   "name" => __($pre_text."Login Form", 'bakix'),
   "base" => "login_form",
   "class" => "",
   "icon" => "icon-st",
   "category" => 'Content',
   "params" => array( 
      array(
         "type" => "textfield",
         "holder" => "div",
         "class" => "",
         "heading" => __("Title", 'bakix'),
         "param_name" => "title",
         "value" => "",
         "description" => __("", 'bakix')
   ),
   )));
}

