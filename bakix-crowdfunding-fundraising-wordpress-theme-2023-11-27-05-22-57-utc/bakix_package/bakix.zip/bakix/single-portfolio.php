<?php
   $bakix_redux_demo = get_option('redux_demo');
   get_header('home3'); 
?>
<?php 
    while (have_posts()): the_post();
?>
<?php $pfl_facebook = get_post_meta(get_the_ID(),'_cmb_pfl_facebook', true); ?>
<?php $pfl_twitter = get_post_meta(get_the_ID(),'_cmb_pfl_twitter', true); ?>
<?php $pfl_behance = get_post_meta(get_the_ID(),'_cmb_pfl_behance', true); ?>
<?php $pfl_linkedin = get_post_meta(get_the_ID(),'_cmb_pfl_linkedin', true); ?>
<?php $pfl_link = get_post_meta(get_the_ID(),'_cmb_pfl_link', true); ?>
<?php $pfl_text_btn = get_post_meta(get_the_ID(),'_cmb_pfl_text_btn', true); ?>
<?php $pfl_type = get_post_meta(get_the_ID(),'_cmb_pfl_type', true); ?>
<?php $pfl_info1 = get_post_meta(get_the_ID(),'_cmb_pfl_info1', true); ?>
<?php $pfl_info2 = get_post_meta(get_the_ID(),'_cmb_pfl_info2', true); ?>
<?php $pledged = get_post_meta(get_the_ID(),'_cmb_pledged', true); ?>
<?php $target = get_post_meta(get_the_ID(),'_cmb_target', true); ?>

<!-- page title start -->
<?php if(isset($bakix_redux_demo['single_portfolio_image']['url']) && $bakix_redux_demo['single_portfolio_image']['url'] != ''){?>
<section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_url($bakix_redux_demo['single_portfolio_image']['url']); ?>">
<?php }else{?>
<section class="page-title-area pt-150 pb-150" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/page-title-4.jpg">
<?php } ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-7 col-lg-8">
                <div class="page-title">
                    <h2><?php if(isset($bakix_redux_demo['single_portfolio_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['single_portfolio_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Project Details', 'bakix' );
                                    }
                                    ?></h2>
                    <p><?php if(isset($bakix_redux_demo['single_portfolio_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['single_portfolio_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                    carousel. You can control and change the features of each.', 'bakix' );
                                    }
                                    ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="event-area pos-relative pt-120 pb-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="project-details pl-15">
                    <?php if ( has_post_thumbnail() ) { ?>
                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" class ="mb-50 "  />
                    <?php } ?>
                    <div class="section-title mb-30">
                        <p><span></span> <?php echo wp_specialchars_decode(esc_attr($pfl_type));?></p>
                        <h1><?php the_title();?></h1>
                    </div>
                    <?php the_content(); ?>
                    <div class="fund-progress mb-50 mt-30">
                        <div class="progress">
                            <div class="progress-bar w-75" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="payment-count details-fund-count d-md-flex justify-content-between mt-20 fix">
                            <div class="fund-count">
                                <?php echo wp_specialchars_decode(esc_attr($pledged));?>
                            </div>
                            <div class="fund-count  ">
                                <?php echo wp_specialchars_decode(esc_attr($target));?>
                            </div>
                            <div class="fund-count  ">
                                <?php echo wp_specialchars_decode(esc_attr($pfl_info1));?>
                            </div>
                            <div class="fund-count  ">
                                <?php echo wp_specialchars_decode(esc_attr($pfl_info2));?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6 col-lg-12">
                <div class="fund-form mb-30">
                    <?php echo do_shortcode( '[contact-form-7 id="292" title="Form Enter Amount"]' ) ?>
                </div>
            </div>
            <div class="col-xl-6 col-lg-12  ">
                <div class="fund-right mb-30">
                    <div class="remind mb-15">
                        <a href="<?php echo wp_specialchars_decode(esc_attr($pfl_link));?>" class="btn btn-black"><i class="fas fa-heart"></i> <?php echo wp_specialchars_decode(esc_attr($pfl_text_btn));?></a>
                    </div>
                    <div class="fund-icon mb-15 ">
                        <?php if($pfl_facebook !='') { ?>
                        <a href="<?php echo esc_url($pfl_facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                        <?php } ?>
                        <?php if($pfl_twitter !='') { ?>
                        <a href="<?php echo esc_url($pfl_twitter); ?>"><i class="fab fa-twitter"></i></a>
                        <?php } ?>
                        <?php if($pfl_behance !='') { ?>
                        <a href="<?php echo esc_url($pfl_behance); ?>"><i class="fab fa-behance"></i></a>
                        <?php } ?>
                        <?php if($pfl_linkedin !='') { ?>
                        <a href="<?php echo esc_url($pfl_linkedin); ?>"><i class="fab fa-linkedin-in"></i></a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="call-to-action-section">
    <div class="auto-container">
        <?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    </div>
</section>
<?php endwhile; ?>
    <!-- FOOTER -->
<?php
    get_footer();
?>