<?php
/*
 * Template Name: Blog 3 Column
 * Description: A Page Template with a Page Builder design.
 */
     $bakix_redux_demo = get_option('redux_demo');
     get_header(); 
?>
<?php $banner_image = get_post_meta(get_the_ID(),'_cmb_banner_image', true); ?>

<main>
  <section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_attr($banner_image);?>">
      <div class="container">
          <div class="row">
              <div class="col-xl-7 col-lg-8">
                  <div class="page-title page-title-white">
                      <h2><?php the_title();?></h2>
                      <p class="pl-0"><?php if(isset($bakix_redux_demo['blog_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['blog_details_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                          carousel. You can control and change the features of each.', 'bakix' );
                                    }
                                    ?></p>
                  </div>
              </div>
          </div>
      </div>
  </section>

<section class="blog-area pt-120 pb-80">
    <div class="container">
        <div class="row">
            <!--Content Side-->
                <?php  $args = array(    
                                'paged' => $paged,
                                'post_type' => 'post',
                                'posts_per_page' => $bakix_redux_demo['3col_number'],
                        );
                    $wp_query = new WP_Query($args);
                    while (have_posts()): the_post(); ?>
                    <?php $featured_image_3 = get_post_meta(get_the_ID(),'_cmb_featured_image_3', true); ?>
                    <div class="col-lg-4 col-md-6">
                        <article class="postbox post format-image mb-40">
                            <div class="postbox__thumb">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_attr($featured_image_3);?>" alt="blog image">
                                </a>
                            </div>
                            <div class="postbox__text p-30">
                                <div class="post-meta mb-15">
                                    <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?> </a></span>
                                    <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                                </div>
                                <h3 class="blog-title blog-title-sm">
                                    <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                </h3>
                                <div class="post-text">
                                    <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                                </div>
                                <div class="read-more">
                                    <a href="<?php the_permalink();?>" class="read-more"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?> <i class="flaticon-right-arrow-1"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>
                    
                    <?php endwhile; ?>
                </div>
                <!--Styled Pagination-->
                <div class="row">
                    <div class="col-12">
                        <div class="basic-pagination basic-pagination-2 text-center mb-40">
                    <?php bakix_pagination();?>
                        </div>
                    </div>
                </div>
                <!--End Styled Pagination-->
    </div>
</section>
    <!-- FOOTER -->
<?php
    get_footer();
?>