<?php
/*
 * Template Name: Event
 * Description: A Page Template with a Page Builder design.
 */
     $bakix_redux_demo = get_option('redux_demo');
     get_header('home1'); 
?>
<?php $banner_image = get_post_meta(get_the_ID(),'_cmb_banner_image', true); ?>
<main>
<section class="page-title-area pt-320 pb-140" data-background="<?php echo esc_attr($banner_image);?>">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="page-title page-title-white text-center">
                    <h2><?php if(isset($bakix_redux_demo['event_title'])){?>
                                <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['event_title']));?>
                                <?php }else{?>
                                <?php echo esc_html__( 'Our Event', 'bakix' );
                                }
                                ?></h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="event-area pos-relative event-bg pt-120 pb-120">
    <div class="event-shape spahe1 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p1.png"  ></div>
    <div class="event-shape spahe2 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p2.png"  ></div>
    <div class="event-shape spahe3 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p3.png"  ></div>
    <div class="event-shape spahe4 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p4.png"  ></div>
    <div class="event-shape spahe5 bounce-animate" data-depth=".3"><img src="<?php echo get_template_directory_uri();?>/assets/img/event/p5.png"  ></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-9 col-lg-8">
                <div class="section-title white-text mb-65">
                    <?php if(isset($bakix_redux_demo['event_content_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['event_content_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 d-none d-xl-block">
                <div class="section-link mb-65 text-right">
                    <a class="btn-border btn-soft" href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_btn_event']));?>"><?php if(isset($bakix_redux_demo['button_more_event'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['button_more_event']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'more events', 'bakix' );
                                    }
                                    ?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="basic-tab">
                    <ul class="nav tab-menu justify-content-center mb-50" id="eventTab" role="tablist">
                        <?php 
                         $b = 0;
                            $categories = get_terms('type1');   
                             foreach( (array)$categories as $categorie){
                                $cat_name = $categorie->name;
                                $cat_slug = $categorie->slug;
                                $b++;
                        ?>
                        <?php if($b == 2){?>
                        <li class="nav-item">
                            <a class="nav-link active" id="profile-tabe" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                 aria-selected="false"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }else{?>

                        <li class="nav-item">
                            <a class="nav-link" id="home-tabe" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-selected="true"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }?>
                        <?php } ?>
                    </ul>
                    <div class="tab-content" id="emyTabContent">
                        <?php 
                        $a = 0;
                            $categories = get_terms('type1');   
                             foreach( (array)$categories as $categorie){
                                $cat_name1 = $categorie->name;
                                $cat_slug1 = $categorie->slug;
                                $a++;
                                $class1 = '';
                                if($a == 2){
                                    $class1 = "show active";
                                }
                        ?>
                            <div class="tab-pane fade <?php echo esc_attr($class1);?>" id="<?php echo esc_attr($cat_slug1);?>" role="tabpanel">
                                <?php 
                                    $args = array(   
                                                'post_type' => 'event',   
                                                'paged' => $paged,
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'type1',
                                                        'field'    => 'slug',
                                                        'terms'    => $cat_slug1,
                                                    ),
                                                ),
                                            );  
                                            $wp_query = new WP_Query($args);
                                            $i = 1;
                                            while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                            $i++;
                                ?>
                                <?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
                                <?php $end_day = get_post_meta(get_the_ID(),'_cmb_end_day', true); ?>
                                <?php $time = get_post_meta(get_the_ID(),'_cmb_time', true); ?>
                                <?php $start_day = get_post_meta(get_the_ID(),'_cmb_start_day', true); ?>
                                <?php $type_event = get_post_meta(get_the_ID(),'_cmb_type_event', true); ?>
                                <?php $info2 = get_post_meta(get_the_ID(),'_cmb_info2', true); ?>
                                <?php $info1 = get_post_meta(get_the_ID(),'_cmb_info1', true); ?>
                                <?php $countdown = get_post_meta(get_the_ID(),'_cmb_countdown', true); ?>
                                <?php $event_image_2 = get_post_meta(get_the_ID(),'_cmb_event_image_2', true); ?>
                                <div class="event-wrapper mb-40">
                                    <div class="row">
                                        <div class="col-lg-3 d-flex align-items-center">
                                            <div class="event-time">
                                                <div class="event-icon mb-20">
                                                    <img src="<?php echo esc_attr($event_image_2);?>"  >
                                                </div>
                                                <div class="event-time-text">
                                                    <h4><?php echo wp_specialchars_decode(esc_attr($time));?></h4>
                                                    <span><?php echo esc_attr($type_event);?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 d-flex align-items-center ">
                                            <div class="event-info">
                                                <h3><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
                                                <div class="event-meta mb-15">
                                                    <span><?php echo wp_specialchars_decode(esc_attr($info2));?></span>
                                                    <span><?php echo wp_specialchars_decode(esc_attr($info1));?></span>
                                                </div>
                                                <p><?php if(isset($bakix_redux_demo['event_excerpt'])){?>
                                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['event_excerpt'])); ?>
                                                <?php }else{?>
                                                <?php echo esc_attr(bakix_excerpt(20)); 
                                                }
                                                ?></p>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 d-flex align-items-center justify-content-start justify-content-lg-end">
                                            <div class="event-btn">
                                                <a href="<?php the_permalink(); ?>" class="btn-circle"><?php if(isset($bakix_redux_demo['event_read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['event_read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Join Today', 'bakix' );
                                    }
                                    ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php  endwhile; ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    <!-- FOOTER -->
<?php
    get_footer();
?>