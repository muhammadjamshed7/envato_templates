<?php
/*
 * Template Name: Team
 * Description: A Page Template with a Page Builder design.
 */
     $bakix_redux_demo = get_option('redux_demo');
     get_header(); 
?>
<?php $banner_image = get_post_meta(get_the_ID(),'_cmb_banner_image', true); ?>
<main>
<section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_attr($banner_image);?>">
    <div class="container">
        <div class="row">
            <div class="col-xl-7 col-lg-8">
                <div class="page-title">
                    <h2><?php if(isset($bakix_redux_demo['team_title'])){?>
                                <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['team_title']));?>
                                <?php }else{?>
                                <?php echo esc_html__( 'Our Team', 'bakix' );
                                }
                                ?></h2>
                    <p><?php if(isset($bakix_redux_demo['team_subtitle'])){?>
                                <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['team_subtitle']));?>
                                <?php }else{?>
                                <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                      carousel. You can control and change the features of each.', 'bakix' );
                                }
                                ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="team-area pt-120 pb-90">
    <div class="container">
        <div class="row">
        <!--Content Side-->
            <?php  $args = array(    
                            'paged' => $paged,
                            'post_type' => 'team',
                            'posts_per_page' => $bakix_redux_demo['team_number'], 
                    );
                $wp_query = new WP_Query($args);
                while (have_posts()): the_post(); ?>
                <?php $team_image_2 = get_post_meta(get_the_ID(),'_cmb_team_image_2', true); ?>
                <?php $team_position = get_post_meta(get_the_ID(),'_cmb_team_position', true); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="team mb-30">
                            <div class="team__img">
                                <img src="<?php echo esc_attr($team_image_2);?>"  >
                            </div>
                            <div class="team__content text-center white-bg">
                                <h4><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h4>
                                <span><?php echo esc_attr($team_position);?></span>
                            </div>
                        </div>
                    </div>

                <?php endwhile; ?>
        </div>
        <!--Styled Pagination-->
        <div class="row">
            <div class="col-12">
                <div class="basic-pagination basic-pagination-2 text-center mb-40">
                    <?php bakix_pagination();?>
                </div>
            </div>
        </div>
        <!--End Styled Pagination-->
    </div>
</section>
<?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    <!-- FOOTER -->
<?php
    get_footer();
?>