<?php
/*
 * Template Name: Blog Right Sidebar
 * Description: A Page Template with a Page Builder design.
 */
     $bakix_redux_demo = get_option('redux_demo');
     get_header(); 
?>
<?php $banner_image = get_post_meta(get_the_ID(),'_cmb_banner_image', true); ?>
<main>
  <section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_attr($banner_image);?>">
      <div class="container">
          <div class="row">
              <div class="col-xl-7 col-lg-8">
                  <div class="page-title page-title-white">
                      <h2><?php the_title();?></h2>
                      <p class="pl-0"><?php if(isset($bakix_redux_demo['blog_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['blog_details_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                          carousel. You can control and change the features of each.', 'bakix' );
                                    }
                                    ?></p>
                  </div>
              </div>
          </div>
      </div>
  </section>

<section class="blog-area pt-120 pb-80">
    <div class="container">
        <div class="row">
            <!--Content Side-->
            <div class="col-lg-8">
                <?php  $args = array(    
                                'paged' => $paged,
                                'post_type' => 'post',
                        );
                    $wp_query = new WP_Query($args);
                    while (have_posts()): the_post(); ?>
                    <?php $audio_link = get_post_meta(get_the_ID(),'_cmb_audio_link', true); ?>
                    <?php $video_link = get_post_meta(get_the_ID(),'_cmb_video_link', true); ?>
                    <?php $img_gallery_1 = get_post_meta(get_the_ID(),'_cmb_img_gallery_1', true); ?>
                    <?php $img_gallery_2 = get_post_meta(get_the_ID(),'_cmb_img_gallery_2', true); ?>
                    <?php $img_gallery_3 = get_post_meta(get_the_ID(),'_cmb_img_gallery_3', true); ?>

                    <?php if( has_post_format( 'image' , $post_id ) ) {?>

                    <article class="postbox post format-image mb-40">
                        <div class="postbox__thumb">
                            <a href="<?php the_permalink();?>">
                                <?php if ( has_post_thumbnail() ) { ?>
                                <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="blog image" />
                                <?php } ?>
                            </a>
                        </div>
                        <div class="postbox__text p-50">
                            <div class="post-meta mb-15">
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <h3 class="blog-title">
                                <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            </h3>
                            <div class="post-text mb-20">
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                            </div>
                            <div class="read-more mt-30">
                                <a href="<?php the_permalink();?>" class="btn btn-black"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                    </article>

                    <?php } elseif ( has_post_format( 'audio' , $post_id )) { ?>

                    <article class="postbox post format-audio mb-40">
                        <div class="postbox__audio embed-responsive embed-responsive-16by9">
                            <iframe src="<?php echo esc_url($audio_link); ?>"></iframe>
                        </div>
                        <div class="postbox__text p-50">
                            <div class="post-meta mb-15">
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <h3 class="blog-title">
                                <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            </h3>
                            <div class="post-text mb-20">
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                            </div>
                            <div class="read-more mt-30">
                                <a href="<?php the_permalink();?>" class="btn btn-black"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                    </article>

                    <?php } elseif ( has_post_format( 'video' , $post_id )) { ?> 

                    <article class="postbox post format-video mb-40">
                        <div class="postbox__video">
                            <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="blog image">
                            <a class="popup-video video-btn" href="<?php echo esc_url($video_link); ?>"><i class="fas fa-play"></i></a>
                        </div>
                        <div class="postbox__text p-50">
                            <div class="post-meta mb-15">
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <h3 class="blog-title">
                                <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            </h3>
                            <div class="post-text mb-20">
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                            </div>
                            <div class="read-more mt-30">
                                <a href="<?php the_permalink();?>" class="btn btn-black"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                    </article>
                    <?php } elseif ( has_post_format( 'gallery' , $post_id )) { ?>  

                    <article class="postbox post format-gallery mb-40">
                        <div class="postbox__gallery">
                            <img src="<?php echo esc_attr($img_gallery_1);?>" alt="blog image">
                            <img src="<?php echo esc_attr($img_gallery_2);?>" alt="blog image">
                            <img src="<?php echo esc_attr($img_gallery_3);?>" alt="blog image">
                        </div>
                        <div class="postbox__text p-50">
                            <div class="post-meta mb-15">
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <h3 class="blog-title">
                                <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            </h3>
                            <div class="post-text mb-20">
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                            </div>
                            <div class="read-more mt-30">
                                <a href="<?php the_permalink();?>" class="btn btn-black"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                    </article>
                    <?php } elseif ( has_post_format( 'quote' , $post_id )) { ?> 
                    <article class="postbox post format-quote mb-40">
                        <div class="post-text">
                            <blockquote>
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                                <footer>- <?php the_author_posts_link(); ?></footer>
                            </blockquote>
                        </div>
                    </article>
                    <?php } else{?>
                    <article class="postbox post format-gallery mb-40">
                        <div class="postbox__text p-50">
                            <div class="post-meta mb-15">
                                <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                                <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                                <span><a href="#"><i class="far fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__(' 1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></a></span>
                            </div>
                            <h3 class="blog-title">
                                <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            </h3>
                            <div class="post-text mb-20">
                                <p><?php if(isset($bakix_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(bakix_excerpt($bakix_redux_demo['blog_excerpt'])); ?>
                                <?php }else{?>
                                <?php echo esc_attr(bakix_excerpt(40)); 
                                }
                                ?></p>
                            </div>
                            <div class="read-more mt-30">
                                <a href="<?php the_permalink();?>" class="btn btn-black"><?php if(isset($bakix_redux_demo['read_more'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['read_more']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Read More', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                    </article>
                    <?php } ?>   

                    <?php endwhile; ?>
                    <!--Styled Pagination-->
                    <div class="basic-pagination basic-pagination-2 mb-40">
                        <?php bakix_pagination();?>
                    </div>
                    <!--End Styled Pagination-->
            </div>
                
            <!--Sidebar Side-->
            <div class="col-lg-4">
                <?php get_sidebar();?>
            </div>
            
        </div>
    </div>
</section>
    <!-- FOOTER -->
<?php
    get_footer();
?>