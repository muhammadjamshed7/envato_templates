<?php
/*
 * Template Name: Support
 * Description: A Page Template with a Page Builder design.
 */
     $bakix_redux_demo = get_option('redux_demo');
     get_header('home3'); 
?>
<main>
    <!-- page-title-area start -->
    <section class="page-title-area pt-150 pb-150" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/page-title-support.jpg">
        <div class="container">
            <div class="row">
                <div class="col-xl-8 offset-xl-2">
                    <div class="page-title page-title-white text-center">
                        <h2>Our Support Center</h2>
                        <p>List as many team members as you want in two layout modes: standard &
                        carousel. You can control and change the features of each.</p>
                        <div class="faq-form">
                            <form action="#">
                                <input type="text" placeholder="Have a question? Ask everything here.">
                                <button class="btn btn-theme" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- page-title-area end -->

    <!-- Marketplace-area start -->
    <section class="faq-area grey-bg pt-120 pb-65">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="faq-tab">
                        <ul class="nav text-center pb-30 mb-50" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                                    aria-controls="home" aria-selected="true">Crowdfunding </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                                    aria-controls="profile" aria-selected="false">Marketplace</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Trouble with Backix?</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Account access</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Legal and privacy</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Manage your account</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Pins and boards</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>All about Pinterest</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Change your email</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Change your password?</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Bot on your network</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Missing Pins or boards</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Merge accounts</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Account suspension</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <div class="row">
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Bot on your network</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Missing Pins or boards</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Trouble with Backix?</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Manage your account</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Pins and boards</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Account access</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Legal and privacy</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>All about Pinterest</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Change your email</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Change your password?</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Merge accounts</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="faq mb-50">
                                        <h3>Account suspension</h3>
                                        <ul>
                                            <li><a href="#">Directed to App store or Play store</a></li>
                                            <li><a href="#">Limits for Pins, boards, and follows</a></li>
                                            <li><a href="#">Merge accounts</a></li>
                                            <li><a href="#">Missing Pins or boards</a></li>
                                        </ul>
                                        <div class="faq-link mt-25">
                                            <a href="#"><i class="fas fa-caret-right"></i> Read More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Marketplace-area end -->

    <!-- brand-area start -->
    <section class="brand-area pt-110 pb-120" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/footer.jpg">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="brand-heading text-center mb-80">
                        <h3>What Client Working With BAKIX And They Are Happy</h3>
                    </div>
                    <div class="brand-active owl-carousel">
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand1.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand2.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand3.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand4.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand5.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand6.png"  >
                        </div>
                        <div class="single-brand">
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/brand2.png"  >
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- brand-area end -->

</main>
<?php
    get_footer();
?>