<?php
/*
 * Template Name: Portfolio 
 * Description: A Page Template with a Page Builder design.
 */
   $bakix_redux_demo = get_option('redux_demo');
   get_header('home3'); 
?>
<?php $banner_image = get_post_meta(get_the_ID(),'_cmb_banner_image', true); ?>
<!-- page title start -->
<section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_attr($banner_image);?>">
    <div class="container">
        <div class="row">
            <div class="col-xl-7 col-lg-8">
                <div class="page-title">
                    <h2><?php if(isset($bakix_redux_demo['portfolio_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['portfolio_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Our Portfolio', 'bakix' );
                                    }
                                    ?></h2>
                    <p><?php if(isset($bakix_redux_demo['portfolio_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['portfolio_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                    carousel. You can control and change the features of each.', 'bakix' );
                                    }
                                    ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="causes-area grey-bg pt-120 pb-90">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-9 col-lg-9">
                <div class="section-title mb-65">
                    <?php if(isset($bakix_redux_demo['portfolio_content_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['portfolio_content_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 d-none d-xl-block">
                <div class="section-link mb-65 text-right">
                    <a class="btn-border" href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_btn_portfolio']));?>"><?php if(isset($bakix_redux_demo['button_more_portfolio'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['button_more_portfolio']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'other portfolio', 'bakix' );
                                    }
                                    ?></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="causes-tab">
                    <ul class="nav theme-bg text-center mb-75" id="myTab" role="tablist">
                        <?php 
                         $b = 0;
                            $categories = get_terms('type2');   
                             foreach( (array)$categories as $categorie){
                                $cat_name = $categorie->name;
                                $cat_slug = $categorie->slug;
                                $b++;
                        ?>
                        <?php if($b == 1){?>
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-controls="home" aria-selected="true"><?php echo esc_attr($cat_name);?></a>
                        </li>
                         <?php }else{?>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#<?php echo esc_attr($cat_slug);?>" role="tab"
                                aria-controls="profile" aria-selected="false"><?php echo esc_attr($cat_name);?></a>
                        </li>
                        <?php }?>
                        <?php } ?>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <?php 
                        $a = 0;
                            $categories = get_terms('type2');   
                             foreach( (array)$categories as $categorie){
                                $cat_name1 = $categorie->name;
                                $cat_slug1 = $categorie->slug;
                                $a++;
                                $class1 = '';
                                if($a == 1){
                                    $class1 = "show active";
                                }
                        ?>
                        <div class="tab-pane fade <?php echo esc_attr($class1);?>" id="<?php echo esc_attr($cat_slug1);?>" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <?php 
                                    $args = array(   
                                                'post_type' => 'portfolio',   
                                                'paged' => $paged,
                                                'posts_per_page' => $bakix_redux_demo['portfolio_number'],
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'type2',
                                                        'field'    => 'slug',
                                                        'terms'    => $cat_slug1,
                                                    ),
                                                ),
                                            );  
                                            $wp_query = new WP_Query($args);
                                            $i = 1;
                                            while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                            $i++;
                                ?>
                                <?php $portfolio_image_2 = get_post_meta(get_the_ID(),'_cmb_portfolio_image_2', true); ?>
                                <div class="col-xl-4 col-lg-4 col-md-6">
                                    <div class="causes pos-relative mb-30">
                                        <div class="causes__img">
                                            <img src="<?php echo esc_attr($portfolio_image_2);?>"  >
                                        </div>
                                        <div class="causes__caption portfolio">
                                            <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                            <div class="causes-progress ">
                                                <div class="progress">
                                                    <div class="progress-bar w-100" role="progressbar" aria-valuenow="60"
                                                        aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php  endwhile; ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="call-to-action-section">
    <div class="auto-container">
        <?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    </div>
</section>
    <!-- FOOTER -->
<?php
    get_footer();
?>