<?php
/**
 * The Template for displaying all single posts
 */
 $bakix_redux_demo = get_option('redux_demo');
get_header(); ?>
<?php 
    while (have_posts()): the_post();
?>
<!-- basic-breadcrumb start -->
<?php if(isset($bakix_redux_demo['blog_image_banner_image']['url']) && $bakix_redux_demo['blog_image_banner_image']['url'] != ''){?>
<section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_url($bakix_redux_demo['blog_image_banner_image']['url']); ?>">
<?php }else{?>
<section class="page-title-area pt-150 pb-150" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/page-banner.jpg">
<?php } ?>
    <div class="container">
        <div class="row">
          <div class="col-xl-12">
            <div class="page-title page-title-white text-center">
                <h2><?php the_title(); ?></h2>
            </div>
          </div>
        </div>
    </div>
</section>
<!-- blog-area start -->
<div class="blog-area pt-120 pb-120">
    <div class="container">
        <div class="row">
            <?php if ( is_active_sidebar( 'sidebar-1' ) ){ ?>
            <div class="col-lg-8" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php }else{ ?>
            <div class="col-lg-12" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php } ?>
            <div class="blog-wrapper blog-details">
              <div class="blog-thumb">
                <a href="<?php the_permalink();?>">
                  <?php if ( has_post_thumbnail() ) { ?>
                  <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"  />
                  <?php } ?>
                </a>
              </div>
              <div class="blog-content">
                  <?php the_content(); ?>
                  <?php wp_link_pages( array(
                  'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'bakix' ),
                  'after'       => '</div>',
                  'link_before' => '<span class="page-number">',
                  'link_after'  => '</span>',
                  ) ); ?>
              </div>
              <div class="next-prev-post clearfix">
                <?php previous_post_link('%link',wp_specialchars_decode(esc_html__( '<i class="ion-arrow-left-c"></i> Previous Post','bakix'),ENT_QUOTES), true); ?>
                <div class='right'><?php next_post_link('%link',wp_specialchars_decode(esc_html__('Next Post <i class="ion-arrow-right-c"></i>','bakix'),ENT_QUOTES), true); ?></div>
              </div>
             <?php           
                if ( comments_open() || get_comments_number() ) {
                  comments_template();
                }
                ?>
            </div>        
          </div>
          <?php if ( is_active_sidebar( 'sidebar-1' ) ){ ?>
            <div class="col-lg-4">
                <?php get_sidebar();?>
            </div>  
            <?php }else{ ?>
            <?php } ?>
    </div>
  </div>
</div>
  <?php endwhile; ?>

  <!-- blog-area end -->
 <?php get_footer('home2');?>