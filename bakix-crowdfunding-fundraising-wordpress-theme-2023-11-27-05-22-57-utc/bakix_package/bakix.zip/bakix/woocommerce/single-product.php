<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
 $bakix_redux_demo = get_option('redux_demo');
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'home1' ); ?>
<?php while ( have_posts() ) : the_post(); ?>

<main class = "woocommerce">
    <?php if(isset($bakix_redux_demo['shop_details_image']['url']) && $bakix_redux_demo['shop_details_image']['url'] != ''){?>
    <section class="page-title-area pt-320 pb-140" data-background="<?php echo esc_url($bakix_redux_demo['shop_details_image']['url']); ?>">
    <?php }else{?>
    <section class="page-title-area pt-320 pb-140" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/breadcumb.jpg">
    <?php } ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="page-title page-title-white text-center">
                        <h2><?php if(isset($bakix_redux_demo['shop_details_title'])){?>
                                    <?php echo htmlspecialchars_decode(esc_attr($bakix_redux_demo['shop_details_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Product Details', 'bakix' );
                                    }
                                    ?></h2>
                        <div class="breadcrumb-list">
                            <ul>
                                <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php if(isset($bakix_redux_demo['home_text'])){?>
                                    <?php echo htmlspecialchars_decode(esc_attr($bakix_redux_demo['home_text']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Home', 'bakix' );
                                    }
                                    ?></a></li>
                                <li><?php if(isset($bakix_redux_demo['shop_details_title'])){?>
                                    <?php echo htmlspecialchars_decode(esc_attr($bakix_redux_demo['shop_details_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Product Details', 'bakix' );
                                    }
                                    ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="shop-banner-area pt-120 pb-90">
      <div class="container">
        <div class="row">
          <div class = content-products>
              <?php
                /**
                 * woocommerce_before_single_product_summary hook
                 *
                 * @hooked woocommerce_show_product_sale_flash - 10
                 * @hooked woocommerce_show_product_images - 20
                 */
                do_action( 'woocommerce_before_single_product_summary' );
              ?>
                <?php wc_get_template_part( 'content', 'single-product' ); ?>
          </div>
	    </div>
	   </div>
	</section>
    <section class="product-desc-area pb-120">
        <div class="container">
            <div class="row">
                <?php
                    /**
                     * woocommerce_after_single_product_summary hook.
                     *
                     * @hooked woocommerce_output_product_data_tabs - 10
                     * @hooked woocommerce_upsell_display - 15
                     * @hooked woocommerce_output_related_products - 20
                     */
                    do_action( 'woocommerce_after_single_product_summary' );
                ?>
            </div>
        </div>
    </section>
</main>

 <?php endwhile; // end of the loop. ?>
<?php get_footer( 'shop' ); ?>
