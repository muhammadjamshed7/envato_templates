<?php
   $bakix_redux_demo = get_option('redux_demo');
   get_header(); 
?>
<?php 
    while (have_posts()): the_post();
?>
<?php $team_facebook = get_post_meta(get_the_ID(),'_cmb_team_facebook', true); ?>
<?php $team_twitter = get_post_meta(get_the_ID(),'_cmb_team_twitter', true); ?>
<?php $team_behance = get_post_meta(get_the_ID(),'_cmb_team_behance', true); ?>
<?php $team_linkedin = get_post_meta(get_the_ID(),'_cmb_team_linkedin', true); ?>
<?php $team_youtube = get_post_meta(get_the_ID(),'_cmb_team_youtube', true); ?>
<?php $team_position = get_post_meta(get_the_ID(),'_cmb_team_position', true); ?>
<?php $team_descr = get_post_meta(get_the_ID(),'_cmb_team_descr', true); ?>
<?php $team_phone = get_post_meta(get_the_ID(),'_cmb_team_phone', true); ?>
<?php $team_mail = get_post_meta(get_the_ID(),'_cmb_team_mail', true); ?>

<main>
    <!-- page-title-area start -->
    <?php if(isset($bakix_redux_demo['single_team_image']['url']) && $bakix_redux_demo['single_team_image']['url'] != ''){?>
	  <section class="page-title-area pt-150 pb-150" data-background="<?php echo esc_url($bakix_redux_demo['single_team_image']['url']); ?>">
	  <?php }else{?>
	  <section class="page-title-area pt-150 pb-150" data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/team-page.jpg">
	  <?php } ?> 
        <div class="container">
            <div class="row">
                <div class="col-xl-7">
                    <div class="page-title">
                        <h2><?php if(isset($bakix_redux_demo['single_team_title'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['single_team_title']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'Member Details', 'bakix' );
                                    }
                                    ?></h2>
                        <p><?php if(isset($bakix_redux_demo['single_team_subtitle'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['single_team_subtitle']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'List as many team members as you want in two layout modes: standard &
                          carousel. You can control and change the features of each.', 'bakix' );
                                    }
                                    ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- page-title-area end -->
    <!-- team-area start -->
    <section class="team-area pt-120 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-lg-5">
                    <div class="team mb-50">
                        <div class="team__thumb">
                            <?php if ( has_post_thumbnail() ) { ?>
	                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>"   />
	                        <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7">
                    <div class="team-details pl-50">
                        <div class="section-title mb-40">
                            <p><span></span> <?php echo esc_attr($team_position);?></p>
                            <h1><?php the_title();?></h1>
                            <h5><?php echo esc_attr($team_descr);?></h5>
                        </div>
                        <div class="team-info">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="team-cta mb-35">
                                        <h5 class="team-ph"><?php echo esc_attr($team_phone);?></h5>
                                        <h5 class="team-mail"><?php echo esc_attr($team_mail);?></h5>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="team-social  text-md-right mb-35">
                                    	<?php if($team_facebook !='') { ?>
                                        <a href="<?php echo esc_url($team_facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                                        <?php } ?>
                                        <?php if($team_twitter !='') { ?>
                                        <a href="<?php echo esc_url($team_twitter); ?>"><i class="fab fa-twitter"></i></a>
                                        <?php } ?>
                                        <?php if($team_behance !='') { ?>
                                        <a href="<?php echo esc_url($team_behance); ?>"><i class="fab fa-behance"></i></a>
                                        <?php } ?>
                                        <?php if($team_linkedin !='') { ?>
                                        <a href="<?php echo esc_url($team_linkedin); ?>"><i class="fab fa-linkedin-in"></i></a>
                                        <?php } ?>
                                        <?php if($team_youtube !='') { ?>
                                        <a href="<?php echo esc_url($team_youtube); ?>"><i class="fab fa-youtube"></i></a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <?php the_content(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- team-area end -->

    <!-- cta-area start -->
    <?php if(isset($bakix_redux_demo['template_contact'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['template_contact']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '', 'bakix' );
                                    }
                                    ?>
    <!-- cta-area end -->

</main>
<?php endwhile; ?>
<?php
    get_footer();
?>