<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>
<?php $bakix_redux_demo = get_option('redux_demo'); ?>
    <head>
      <meta charset="<?php bloginfo( 'charset' ); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) {
          ?>
      <link rel="shortcut icon" href="<?php if(isset($bakix_redux_demo['favicon']['url'])){?><?php echo esc_url($bakix_redux_demo['favicon']['url']); ?><?php }?>">
      <?php }?>
    <?php wp_head(); ?>
    </head>
    <body id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>
        <!-- preloader end  -->

        <!-- header start -->
    <header class="header">
        <div class="header-top-area theme-bg pl-65 pr-65 d-none d-md-block">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-7">
                        <div class="header-cta">
                            <span><i class="fas fa-envelope"></i> <?php if(isset($bakix_redux_demo['mail'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['mail']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'info@example.com', 'bakix' );
                                    }
                                    ?></span>
                            <span><i class="fas fa-phone"></i> <?php if(isset($bakix_redux_demo['phone'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['phone']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( '+980(786) 123 456', 'bakix' );
                                    }
                                    ?></span>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-5 ">
                        <div class="header-social-icon f-right ml-20">
                            <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_fb']));?>"><i class="fab fa-facebook-f"></i></a>
                            <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_tw']));?>"><i class="fab fa-twitter"></i></a>
                            <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_be']));?>"><i class="fab fa-behance"></i></a>
                            <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_lin']));?>"><i class="fab fa-linkedin-in"></i></a>
                            <a href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_yt']));?>"><i class="fab fa-youtube"></i></a>
                        </div>
                        <div class="language f-right">
                            <ul>
                                <li><a href="#">ENG <i class="fas fa-chevron-down"></i></a>
                                    <ul class="submenu">
                                        <li><a href="#"><?php echo esc_html__( 'BD', 'bakix' );?></a></li>
                                        <li><a href="#"><?php echo esc_html__( 'IND', 'bakix' );?></a></li>
                                        <li><a href="#"><?php echo esc_html__( 'JAP', 'bakix' );?></a></li>
                                        <li><a href="#"><?php echo esc_html__( 'CHI', 'bakix' );?></a></li>
                                        <li><a href="#"><?php echo esc_html__( 'USA', 'bakix' );?></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="sticky-header" class="header-box header-no-bg pl-65 pr-65">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-2 col-lg-2 col-md-3 col-6 d-flex align-items-center">
                        <div class="header__logo">
                            <a href="<?php echo esc_url(home_url('/')); ?>">
                              <?php if(isset($bakix_redux_demo['logo']['url']) && $bakix_redux_demo['logo']['url'] != ''){ ?>
                              <img src="<?php echo esc_url($bakix_redux_demo['logo']['url']); ?>" alt="">
                              <?php }else{ ?>
                                  <img src="<?php echo get_template_directory_uri();?>/assets/img/logo/logo.png" alt="">
                              <?php } ?></a>
                        </div>
                    </div>
                    <div class="col-xl-10 col-lg-10 col-6 col-md-9">
                        <div class="header__right f-right">
                            <div class="header__icon f-right mt-30">
                                <a class="login-btn theme-bg" href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_login']));?>"><i class="fas fa-lock"></i></a>
                            </div>
                            <div class="header__icon f-right mt-30 ml-30 d-none d-md-block d-lg-none d-xl-block">
                                <a class="btn" href="<?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['link_btn']));?>"><?php if(isset($bakix_redux_demo['text_button'])){?>
                                    <?php echo wp_specialchars_decode(esc_attr($bakix_redux_demo['text_button']));?>
                                    <?php }else{?>
                                    <?php echo esc_html__( 'start campaign', 'bakix' );
                                    }
                                    ?></a>
                            </div>
                        </div>
                        <div class="header__menu f-right">
                            <nav id="mobile-menu">
                                <?php 
                                      wp_nav_menu( 
                                      array( 
                                            'theme_location' => 'primary',
                                            'container' => '',
                                            'menu_class' => '', 
                                            'menu_id' => '',
                                            'menu'            => '',
                                            'container_class' => '',
                                            'container_id'    => '',
                                            'echo'            => true,
                                             'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                             'walker'            => new bakix_wp_bootstrap_navwalker(),
                                            'before'          => '',
                                            'after'           => '',
                                            'link_before'     => '',
                                            'link_after'      => '',
                                            'items_wrap'      => '<ul  class=" %2$s">%3$s</ul>',
                                            'depth'           => 0,        
                                        )
                                     ); ?>
                            </nav>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile-menu"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>