<?php $bakix_redux_demo = get_option('redux_demo');?> 


<?php if(isset($bakix_redux_demo['footer_background']['url']) && $bakix_redux_demo['footer_background']['url'] != ''){?>
  <footer data-background="<?php echo esc_url($bakix_redux_demo['footer_background']['url']); ?>">
  <?php }else{?>
  <footer data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/footer-bg.jpg">
  <?php } ?> 
            <div class="footer-area footer-bootm-border pt-120 pb-120">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="footer-info text-center">
                                <div class="footer-logo mb-45">
                                    <?php if(isset($bakix_redux_demo['footer_logo']['url']) && $bakix_redux_demo['footer_logo']['url'] != ''){ ?>
                                      <img src="<?php echo esc_url($bakix_redux_demo['footer_logo']['url']); ?>"  >
                                      <?php }else{ ?>
                                          <img src="<?php echo get_template_directory_uri();?>/assets/img/logo/footer-logo.png"  >
                                      <?php } ?>
                                </div>
                                <div class="right-text">
                                    <p><?php echo esc_html__( 'Copyright All Right Reserved By SHTheme - 2019', 'bakix' );?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
<?php wp_footer(); ?>
</body>
</html>