<?php $bakix_redux_demo = get_option('redux_demo');?> 

</main>

        <!-- footer start -->
<?php if(isset($bakix_redux_demo['footer_background']['url']) && $bakix_redux_demo['footer_background']['url'] != ''){?>
  <footer data-background="<?php echo esc_url($bakix_redux_demo['footer_background']['url']); ?>">
  <?php }else{?>
  <footer data-background="<?php echo get_template_directory_uri();?>/assets/img/bg/footer-bg.jpg">
  <?php } ?>    
    
    <div class="copyright-area">
        <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-12 col-lg-12">
                        <div class="right-text text-center">
                            <p><?php echo esc_html__( 'Copyright All Right Reserved By SHTheme - 2019', 'bakix' );?></p>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>