<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains comments and the comment form.
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() )
    return;
?>

<?php if ( have_comments() ) : ?>
  <div class="post-comments">
   <div class="blog-coment-title mb-30">
      <h2><?php comments_number( esc_html__('0 Comments', 'bakix'), esc_html__('1 Comment', 'bakix'), esc_html__('% Comments', 'bakix') ); ?></h2>
  </div>
  <div class="latest-comments">
        <ul>
    <?php wp_list_comments('callback=bakix_theme_comment'); ?>
        </ul>
    </div>      
  </div>
        <!-- START PAGINATION -->
    <?php
        if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
    ?>
        <div class="pagination_area">
             <nav>
                  <ul class="pagination">
                       <li> <?php paginate_comments_links( 
                      array(
                      'prev_text' => wp_specialchars_decode(esc_html__( '<i class="fa fa-angle-left"></i>', 'bakix' ),ENT_QUOTES),
                      'next_text' => wp_specialchars_decode(esc_html__( '<i class="fa fa-angle-right"></i>', 'bakix' ),ENT_QUOTES),
                      ));  ?>
                        </li>
                  </ul>
             </nav>
        </div>
        <?php endif; ?>
        <!-- END PAGINATION --> 
<?php endif; ?>
                        
<?php
    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
        $aria_req = ( $req ? " aria-required='true'" : '' );
        $comment_args = array(
                'id_form' => 'contacts-form',        
                'class_form' => 'conatct-post-form',                         
                'title_reply'=> wp_specialchars_decode( 'Leave a Comment', 'bakix' ),
                'fields' => apply_filters( 'comment_form_default_fields', array(
                    'author' => ' <div class="col-xl-12">
                                    <div class="contact-icon contacts-name">
                                        <input id="name" type="text" placeholder="'.esc_attr__('Your Name.... ', 'bakix').'" name="name" required="required" data-error="'.esc_attr__('Name is required. ', 'bakix').'"/>
                                    </div>                           
                                  </div>',
                    'email' => '  <div class="col-xl-12">
                                    <div class="contact-icon contacts-email">
                                        <input type="email" placeholder="'.esc_attr__('Your Email....', 'bakix').'" name="email" required="required" data-error="'.esc_attr__('Email is required.', 'bakix').'" />
                                    </div>
                                  </div>',
                    'subject' => '<div class="col-xl-12">
                                        <div class="contact-icon contacts-website">
                                            <input type="text" placeholder="'.esc_attr__('Your Website....', 'bakix').'" name="website" required="required" data-error="'.esc_attr__('Website is required.', 'bakix').'" />
                                        </div>
                                  </div>',

                ) ),   
                'comment_field' => '<div class="col-xl-12">
                                      <div class="contact-icon contacts-message">
                                          <textarea name="comment" id="comment" '.$aria_req.' cols="30" rows="10" placeholder="'.esc_attr__('Your Comment....', 'bakix').'" required="required" data-error="'.esc_attr__('Please,leave us a message.', 'bakix').'"></textarea>
                                      </div>
                                    </div>
                                    ',                
                 'label_submit' => esc_html__( 'Post Comment', 'bakix' ),
                 'comment_notes_before' => '',
                 'comment_notes_after' => '',               
        )
    ?>

                          

    <?php if ( comments_open() ) : ?>
    <?php comment_form($comment_args); ?>
                        <?php endif; ?> 
         