import "./assets/css/custom-font.css";

import "./assets/fonts/ClashGroteskSemibold.eot";
import "./assets/fonts/ClashGroteskSemibold.svg";
import "./assets/fonts/ClashGroteskSemibold.ttf";
import "./assets/fonts/ClashGroteskSemibold.woff";
import "./assets/fonts/ClashGroteskSemibold.woff2";
