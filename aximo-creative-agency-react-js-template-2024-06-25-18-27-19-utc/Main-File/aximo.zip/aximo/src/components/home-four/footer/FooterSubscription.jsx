function FooterSubscription() {
	return (
		<div className="aximo-subscription2">
			<form action="#">
				<input type="email" placeholder="Email Address" />
				<button id="aximo-subscription-btn2" type="submit">
					Subscribe now
				</button>
			</form>
		</div>
	);
}

export default FooterSubscription;
