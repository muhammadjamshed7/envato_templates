function HeaderMobileMenu() {
	return (
		<div className="mobile-menu-trigger light">
			<span></span>
		</div>
	);
}

export default HeaderMobileMenu;
