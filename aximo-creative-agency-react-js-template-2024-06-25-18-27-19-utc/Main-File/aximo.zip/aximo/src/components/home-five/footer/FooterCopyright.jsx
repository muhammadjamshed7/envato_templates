function FooterCopyright() {
	return (
		<div className="aximo-copywright five text-center">
			<p> &copy; Copyright 2024, All Rights Reserved by Mthemeus</p>
		</div>
	);
}

export default FooterCopyright;
