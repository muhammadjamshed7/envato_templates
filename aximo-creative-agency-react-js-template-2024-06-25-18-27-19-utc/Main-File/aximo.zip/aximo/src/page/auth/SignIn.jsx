import SignInForm from "../../components/auth/SignInForm";
function SignIn() {
	return (
		<>
			<SignInForm />
		</>
	);
}

export default SignIn;
