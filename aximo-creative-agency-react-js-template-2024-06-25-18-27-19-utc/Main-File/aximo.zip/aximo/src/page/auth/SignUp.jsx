import SignUpForm from "../../components/auth/SignUpForm";
function SignUp() {
	return (
		<>
			<SignUpForm />
		</>
	);
}

export default SignUp;
